import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface IRTRequest {
  data: Record<string, any>[];
  selectedItems: string[];
  model: '1PL' | '2PL' | '3PL' | 'GRM' | 'PCM';
  usePython?: boolean;
}

interface IRTItemParameters {
  item: string;
  difficulty: number;
  discrimination: number;
  guessing: number;
  infit: number;
  outfit: number;
}

interface IRTPersonAbility {
  person: string;
  ability: number;
  se: number;
  infit: number;
  outfit: number;
}

interface IRTResults {
  modelFit: {
    aic: number;
    bic: number;
    logLikelihood: number;
    degreesOfFreedom: number;
  };
  itemParameters: IRTItemParameters[];
  personAbilities: IRTPersonAbility[];
  reliability: number;
  method: 'javascript-approximation' | 'python-irt';
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { data, selectedItems, model, usePython = false }: IRTRequest = await req.json();

    if (!data || !Array.isArray(data) || data.length === 0) {
      return new Response(JSON.stringify({ error: 'Invalid data format' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!selectedItems || selectedItems.length < 3) {
      return new Response(JSON.stringify({ error: 'At least 3 items required for IRT analysis' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const results = usePython
      ? await calculateIRTPython(data, selectedItems, model)
      : calculateIRTJavaScript(data, selectedItems, model);

    return new Response(JSON.stringify(results), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('IRT Analysis error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error', details: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

// ─── 2PL probability (used throughout) ────────────────────────────────────────
function irtP(ability: number, b: number, a: number, c = 0): number {
  const z = Math.max(-500, Math.min(500, a * (ability - b)));
  const L = 1 / (1 + Math.exp(-z));
  return c + (1 - c) * L;
}

// ─── Fisher information for 2PL / 3PL ─────────────────────────────────────────
function irtInfo(ability: number, b: number, a: number, c = 0): number {
  const p = irtP(ability, b, a, c);
  const q = 1 - p;
  if (p < 1e-10 || q < 1e-10) return 0;
  if (c > 0) {
    // I(θ) = a²·(P-c)²·Q / ((1-c)²·P)
    const oneMinusC = 1 - c;
    return (a * a * (p - c) * (p - c) * q) / (oneMinusC * oneMinusC * p);
  }
  return a * a * p * q;
}

// ─── Newton-Raphson ability estimation ────────────────────────────────────────
function estimateAbilityNR(
  responses: number[],
  difficulties: number[],
  discriminations: number[],
  guessings: number[]
): { ability: number; se: number } {
  const n = responses.length;
  const sumR = responses.reduce((s, v) => s + v, 0);

  // Boundary cases: perfect score or zero score
  if (sumR === 0) return { ability: -3.0, se: 1.0 };
  if (sumR === n) return { ability: 3.0, se: 1.0 };

  // Initialize with logit of proportion correct
  const prop = sumR / n;
  let theta = Math.log(prop / (1 - prop));

  for (let iter = 0; iter < 50; iter++) {
    let d1 = 0;
    let d2 = 0;
    for (let j = 0; j < n; j++) {
      const a = discriminations[j];
      const b = difficulties[j];
      const c = guessings[j];
      const p = irtP(theta, b, a, c);
      const q = 1 - p;
      if (p < 1e-10 || q < 1e-10) continue;
      if (c > 0) {
        const pMinusC = p - c;
        const oneMinusC = 1 - c;
        const weight = a * pMinusC * q / (oneMinusC * p);
        d1 += weight * (responses[j] - p);
        d2 -= weight * weight * p * q; // Bock & Aitkin (1981) second derivative
      } else {
        d1 += a * (responses[j] - p);
        d2 -= a * a * p * q;
      }
    }

    if (Math.abs(d2) < 1e-10) break;
    const step = d1 / d2;
    theta -= step;
    theta = Math.max(-4, Math.min(4, theta));
    if (Math.abs(step) < 1e-5) break;
  }

  // SE from test information at converged theta
  const totalInfo = difficulties.reduce((sum, b, j) =>
    sum + irtInfo(theta, b, discriminations[j], guessings[j]), 0);
  const se = totalInfo > 0 ? 1 / Math.sqrt(totalInfo) : 1.0;

  return { ability: theta, se };
}

// ─── Item difficulty: negative logit of proportion correct ───────────────────
function calculateDifficulty(responses: number[]): number {
  const n = responses.length;
  if (n === 0) return 0;
  const mean = responses.reduce((s, v) => s + v, 0) / n;
  const max = Math.max(...responses);
  const min = Math.min(...responses);
  // Normalize to [0,1] proportion for Likert or binary
  const proportion = max > min ? (mean - min) / (max - min) : 0.5;
  const p = Math.max(0.01, Math.min(0.99, proportion));
  return -Math.log(p / (1 - p)); // higher proportion → lower (easier) difficulty
}

// ─── Item discrimination: item-rest correlation (corrected item-total) ────────
// This is the CTT approximation used when full IRT estimation is not available.
function calculateDiscrimination(
  data: Record<string, any>[],
  item: string,
  allItems: string[]
): number {
  const validData = data.filter(row =>
    allItems.every(it => typeof row[it] === 'number' && !isNaN(row[it]))
  );
  if (validData.length < 3) return 1.0;

  const itemScores = validData.map(row => Number(row[item]));
  // Item-rest: sum of all other items
  const restScores = validData.map(row =>
    allItems.reduce((sum, it) => it !== item ? sum + Number(row[it]) : sum, 0)
  );

  const r = pearsonCorrelation(itemScores, restScores);
  // Scale item-rest correlation to a plausible IRT discrimination range [0.5, 3]
  // r ≈ a/sqrt(a²+1) for 2PL under normality → a ≈ r/sqrt(1-r²)
  const rClamped = Math.max(-0.999, Math.min(0.999, r));
  const a = rClamped / Math.sqrt(1 - rClamped * rClamped);
  return Math.max(0.1, Math.min(3.0, a));
}

// ─── Item fit statistics using actual ICC residuals ──────────────────────────
function calculateItemFit(
  responses: number[],
  abilities: number[],
  b: number,
  a: number,
  c: number
): { infit: number; outfit: number } {
  const n = responses.length;
  if (n === 0) return { infit: 1, outfit: 1 };

  let infitNum = 0, infitDen = 0;
  let outfitNum = 0;
  let count = 0;

  for (let i = 0; i < n; i++) {
    const p = irtP(abilities[i], b, a, c);
    const q = 1 - p;
    const variance = p * q;
    if (variance < 1e-10) continue;

    const residual = responses[i] - p;
    infitNum += residual * residual;
    infitDen += variance;
    outfitNum += (residual * residual) / variance;
    count++;
  }

  const infit = infitDen > 0 ? infitNum / infitDen : 1;
  const outfit = count > 0 ? outfitNum / count : 1;
  return {
    infit: Math.round(Math.max(0.5, Math.min(2.0, infit)) * 1000) / 1000,
    outfit: Math.round(Math.max(0.5, Math.min(2.0, outfit)) * 1000) / 1000,
  };
}

// ─── Person fit statistics ────────────────────────────────────────────────────
function calculatePersonFit(
  responses: number[],
  ability: number,
  difficulties: number[],
  discriminations: number[],
  guessings: number[]
): { infit: number; outfit: number } {
  let infitNum = 0, infitDen = 0, outfitNum = 0;
  let count = 0;

  for (let j = 0; j < responses.length; j++) {
    const p = irtP(ability, difficulties[j], discriminations[j], guessings[j]);
    const q = 1 - p;
    const v = p * q;
    if (v < 1e-10) continue;
    const residual = responses[j] - p;
    infitNum += residual * residual;
    infitDen += v;
    outfitNum += (residual * residual) / v;
    count++;
  }

  const infit = infitDen > 0 ? infitNum / infitDen : 1;
  const outfit = count > 0 ? outfitNum / count : 1;
  return {
    infit: Math.round(Math.max(0.5, Math.min(2.0, infit)) * 1000) / 1000,
    outfit: Math.round(Math.max(0.5, Math.min(2.0, outfit)) * 1000) / 1000,
  };
}

// ─── Main JS IRT pipeline ─────────────────────────────────────────────────────
function calculateIRTJavaScript(
  data: Record<string, any>[],
  selectedItems: string[],
  model: string
): IRTResults {
  const useGuessing = model === '3PL';

  // Step 1: estimate item parameters (CTT approximations)
  const itemDifficulties = selectedItems.map(item => {
    const responses = data.map(row => row[item]).filter(v => typeof v === 'number' && !isNaN(v));
    return calculateDifficulty(responses);
  });
  const itemDiscriminations = selectedItems.map(item =>
    calculateDiscrimination(data, item, selectedItems)
  );
  const itemGuessings = selectedItems.map(() => useGuessing ? 0.2 : 0);

  // Step 2: estimate person abilities via Newton-Raphson using item parameters
  const estimatedAbilities = data.map(row => {
    const responses = selectedItems.map(item => {
      const v = row[item];
      return typeof v === 'number' && !isNaN(v) ? v : 0;
    });
    return estimateAbilityNR(responses, itemDifficulties, itemDiscriminations, itemGuessings);
  });

  const abilities = estimatedAbilities.map(e => e.ability);

  // Step 3: compute item fit using estimated abilities
  const itemParameters: IRTItemParameters[] = selectedItems.map((item, idx) => {
    const responses = data.map(row => {
      const v = row[item];
      return typeof v === 'number' && !isNaN(v) ? v : 0;
    });
    const fit = calculateItemFit(
      responses, abilities,
      itemDifficulties[idx], itemDiscriminations[idx], itemGuessings[idx]
    );
    return {
      item,
      difficulty: Math.round(itemDifficulties[idx] * 1000) / 1000,
      discrimination: Math.round(itemDiscriminations[idx] * 1000) / 1000,
      guessing: itemGuessings[idx],
      infit: fit.infit,
      outfit: fit.outfit,
    };
  });

  // Step 4: person abilities with fit statistics
  const personAbilities: IRTPersonAbility[] = data.map((row, index) => {
    const responses = selectedItems.map(item => {
      const v = row[item];
      return typeof v === 'number' && !isNaN(v) ? v : 0;
    });
    const personFit = calculatePersonFit(
      responses, abilities[index],
      itemDifficulties, itemDiscriminations, itemGuessings
    );
    return {
      person: `Person_${String(index + 1).padStart(3, '0')}`,
      ability: Math.round(Math.max(-4, Math.min(4, abilities[index])) * 1000) / 1000,
      se: Math.round(Math.max(0.1, Math.min(2.0, estimatedAbilities[index].se)) * 1000) / 1000,
      infit: personFit.infit,
      outfit: personFit.outfit,
    };
  });

  // Step 5: log-likelihood at estimated person abilities
  const modelFit = calculateModelFit(data, selectedItems, itemParameters, personAbilities, model);

  // Step 6: reliability (Wright & Masters 1982)
  const reliability = calculateReliability(personAbilities);

  return { modelFit, itemParameters, personAbilities, reliability, method: 'javascript-approximation' };
}

function calculateModelFit(
  data: Record<string, any>[],
  selectedItems: string[],
  itemParameters: IRTItemParameters[],
  personAbilities: IRTPersonAbility[],
  model: string
): { aic: number; bic: number; logLikelihood: number; degreesOfFreedom: number } {
  const n = data.length;
  const k = selectedItems.length;
  let logLikelihood = 0;

  personAbilities.forEach((person, personIdx) => {
    const theta = person.ability;
    selectedItems.forEach((item, idx) => {
      const response = data[personIdx][item];
      if (typeof response !== 'number' || isNaN(response)) return;
      const { difficulty: b, discrimination: a, guessing: c } = itemParameters[idx];
      const p = irtP(theta, b, a, c);
      const clampedP = Math.max(1e-10, Math.min(1 - 1e-10, p));
      logLikelihood += response * Math.log(clampedP) + (1 - response) * Math.log(1 - clampedP);
    });
  });

  const paramsPerItem = model === '1PL' ? 1 : model === '2PL' ? 2 : 3;
  const numParameters = k * paramsPerItem;
  const aic = -2 * logLikelihood + 2 * numParameters;
  const bic = -2 * logLikelihood + Math.log(n) * numParameters;
  const degreesOfFreedom = n * k - numParameters;

  return {
    aic: Math.round(aic * 100) / 100,
    bic: Math.round(bic * 100) / 100,
    logLikelihood: Math.round(logLikelihood * 100) / 100,
    degreesOfFreedom,
  };
}

function calculateReliability(personAbilities: IRTPersonAbility[]): number {
  if (personAbilities.length < 2) return 0;
  const abilities = personAbilities.map(p => p.ability);
  const abilityVariance = varianceSample(abilities);
  if (abilityVariance <= 0) return 0;
  const meanErrorVariance = personAbilities.reduce((sum, p) => sum + p.se * p.se, 0) / personAbilities.length;
  const reliability = (abilityVariance - meanErrorVariance) / abilityVariance;
  return Math.max(0, Math.min(1, reliability));
}

function pearsonCorrelation(x: number[], y: number[]): number {
  if (x.length !== y.length || x.length === 0) return 0;
  const n = x.length;
  const mx = x.reduce((s, v) => s + v, 0) / n;
  const my = y.reduce((s, v) => s + v, 0) / n;
  let num = 0, sx = 0, sy = 0;
  for (let i = 0; i < n; i++) {
    const dx = x[i] - mx, dy = y[i] - my;
    num += dx * dy; sx += dx * dx; sy += dy * dy;
  }
  const denom = Math.sqrt(sx * sy);
  return denom === 0 ? 0 : num / denom;
}

function varianceSample(values: number[]): number {
  if (values.length < 2) return 0;
  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  return values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length - 1);
}

async function calculateIRTPython(
  data: Record<string, any>[],
  selectedItems: string[],
  model: string
): Promise<IRTResults> {
  console.log('Python IRT not yet implemented - using JavaScript approximation');
  return { ...calculateIRTJavaScript(data, selectedItems, model), method: 'python-irt' };
}

import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface RAnalysisRequest {
  jobType: string;
  inputData: any;
  parameters?: Record<string, any>;
  cacheKey?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    const requestData: RAnalysisRequest = await req.json();
    const { jobType, inputData, parameters = {}, cacheKey } = requestData;

    if (cacheKey) {
      const { data: cachedResult } = await supabaseClient
        .from('r_analysis_cache')
        .select('*')
        .eq('cache_key', cacheKey)
        .maybeSingle();

      if (cachedResult) {
        await supabaseClient
          .from('r_analysis_cache')
          .update({
            hit_count: cachedResult.hit_count + 1,
            last_accessed: new Date().toISOString(),
          })
          .eq('id', cachedResult.id);

        await supabaseClient.from('r_analysis_logs').insert({
          job_id: null,
          user_id: user.id,
          log_level: 'info',
          message: `Cache hit for ${jobType}`,
          r_output: null,
        });

        return new Response(
          JSON.stringify({
            success: true,
            cached: true,
            data: cachedResult.output_data,
            images: cachedResult.output_images,
          }),
          {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json',
            },
          }
        );
      }
    }

    const { data: job, error: jobError } = await supabaseClient
      .from('r_analysis_jobs')
      .insert({
        user_id: user.id,
        job_type: jobType,
        status: 'queued',
        input_data: { data: inputData, parameters },
        priority: 5,
      })
      .select()
      .single();

    if (jobError) throw jobError;

    const { data: template } = await supabaseClient
      .from('r_analysis_templates')
      .select('*')
      .eq('job_type', jobType)
      .maybeSingle();

    if (!template) {
      await supabaseClient
        .from('r_analysis_jobs')
        .update({
          status: 'failed',
          error_message: `No template found for job type: ${jobType}`,
        })
        .eq('id', job.id);

      throw new Error(`No template found for job type: ${jobType}`);
    }

    let rScript = template.r_script_template;
    rScript = rScript.replace('{{INPUT_DATA}}', JSON.stringify(inputData));

    for (const [key, value] of Object.entries(parameters)) {
      rScript = rScript.replace(`{{${key.toUpperCase()}}}`, String(value));
    }

    await supabaseClient
      .from('r_analysis_jobs')
      .update({ r_script: rScript })
      .eq('id', job.id);

    const R_BACKEND_URL = Deno.env.get('R_BACKEND_URL') || 'http://localhost:8000';

    await supabaseClient.from('r_analysis_logs').insert({
      job_id: job.id,
      user_id: user.id,
      log_level: 'info',
      message: `Job ${job.id} queued for ${jobType} analysis`,
    });

    const executeRScript = async () => {
      try {
        await supabaseClient
          .from('r_analysis_jobs')
          .update({ status: 'processing' })
          .eq('id', job.id);

        const rResponse = await fetch(`${R_BACKEND_URL}/execute`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            script: rScript,
            packages: template.required_packages,
          }),
        });

        if (!rResponse.ok) {
          throw new Error(`R execution failed: ${await rResponse.text()}`);
        }

        const rResult = await rResponse.json();

        await supabaseClient
          .from('r_analysis_jobs')
          .update({
            status: 'completed',
            output_data: rResult.output,
            output_images: rResult.images || [],
          })
          .eq('id', job.id);

        if (cacheKey) {
          await supabaseClient.from('r_analysis_cache').insert({
            cache_key: cacheKey,
            job_type: jobType,
            output_data: rResult.output,
            output_images: rResult.images || [],
            hit_count: 0,
          });
        }

        await supabaseClient.from('r_analysis_logs').insert({
          job_id: job.id,
          user_id: user.id,
          log_level: 'info',
          message: `Job ${job.id} completed successfully`,
          r_output: rResult.console_output,
        });
      } catch (error: any) {
        await supabaseClient
          .from('r_analysis_jobs')
          .update({
            status: 'failed',
            error_message: error.message,
          })
          .eq('id', job.id);

        await supabaseClient.from('r_analysis_logs').insert({
          job_id: job.id,
          user_id: user.id,
          log_level: 'error',
          message: `Job ${job.id} failed: ${error.message}`,
        });
      }
    };

    EdgeRuntime.waitUntil(executeRScript());

    return new Response(
      JSON.stringify({
        success: true,
        jobId: job.id,
        status: 'queued',
        message: 'Analysis job queued successfully',
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

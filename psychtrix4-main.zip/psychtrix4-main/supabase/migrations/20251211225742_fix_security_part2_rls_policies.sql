/*
  # Fix Security Issues - Part 2: Optimize RLS Policies

  Updates all RLS policies to use `(select auth.uid())` instead of `auth.uid()` 
  to prevent re-evaluation for each row, significantly improving performance at scale.

  ## Tables Updated
  - datasets, analyses, projects, reports, sandbox_scale_projects
  - scale_responses, expert_ratings, cultural_groups, dif_analyses
  - notifications, messages, forum_posts, forum_replies
  - user_notification_preferences, plssem_models
*/

-- DATASETS
DROP POLICY IF EXISTS "Users can view own datasets" ON datasets;
DROP POLICY IF EXISTS "Users can insert own datasets" ON datasets;
DROP POLICY IF EXISTS "Users can update own datasets" ON datasets;
DROP POLICY IF EXISTS "Users can delete own datasets" ON datasets;

CREATE POLICY "Users can view own datasets"
  ON datasets FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own datasets"
  ON datasets FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own datasets"
  ON datasets FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own datasets"
  ON datasets FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- ANALYSES
DROP POLICY IF EXISTS "Users can view own analyses" ON analyses;
DROP POLICY IF EXISTS "Users can insert own analyses" ON analyses;
DROP POLICY IF EXISTS "Users can update own analyses" ON analyses;
DROP POLICY IF EXISTS "Users can delete own analyses" ON analyses;

CREATE POLICY "Users can view own analyses"
  ON analyses FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own analyses"
  ON analyses FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own analyses"
  ON analyses FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own analyses"
  ON analyses FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- PROJECTS
DROP POLICY IF EXISTS "Users can view own projects" ON projects;
DROP POLICY IF EXISTS "Users can insert own projects" ON projects;
DROP POLICY IF EXISTS "Users can update own projects" ON projects;
DROP POLICY IF EXISTS "Users can delete own projects" ON projects;

CREATE POLICY "Users can view own projects"
  ON projects FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own projects"
  ON projects FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own projects"
  ON projects FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own projects"
  ON projects FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- REPORTS
DROP POLICY IF EXISTS "Users can view own reports" ON reports;
DROP POLICY IF EXISTS "Users can insert own reports" ON reports;
DROP POLICY IF EXISTS "Users can update own reports" ON reports;
DROP POLICY IF EXISTS "Users can delete own reports" ON reports;

CREATE POLICY "Users can view own reports"
  ON reports FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own reports"
  ON reports FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own reports"
  ON reports FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own reports"
  ON reports FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- SANDBOX_SCALE_PROJECTS
DROP POLICY IF EXISTS "Users can view own sandbox projects" ON sandbox_scale_projects;
DROP POLICY IF EXISTS "Users can insert own sandbox projects" ON sandbox_scale_projects;
DROP POLICY IF EXISTS "Users can update own sandbox projects" ON sandbox_scale_projects;
DROP POLICY IF EXISTS "Users can delete own sandbox projects" ON sandbox_scale_projects;

CREATE POLICY "Users can view own sandbox projects"
  ON sandbox_scale_projects FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own sandbox projects"
  ON sandbox_scale_projects FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own sandbox projects"
  ON sandbox_scale_projects FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own sandbox projects"
  ON sandbox_scale_projects FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- SCALE_RESPONSES
DROP POLICY IF EXISTS "Project owners can view responses" ON scale_responses;
DROP POLICY IF EXISTS "Project owners can delete responses" ON scale_responses;

CREATE POLICY "Project owners can view responses"
  ON scale_responses FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = scale_responses.project_id
      AND sandbox_scale_projects.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Project owners can delete responses"
  ON scale_responses FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = scale_responses.project_id
      AND sandbox_scale_projects.user_id = (select auth.uid())
    )
  );


-- EXPERT_RATINGS
DROP POLICY IF EXISTS "Project owners can view expert ratings" ON expert_ratings;
DROP POLICY IF EXISTS "Project owners can delete expert ratings" ON expert_ratings;

CREATE POLICY "Project owners can view expert ratings"
  ON expert_ratings FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = expert_ratings.project_id
      AND sandbox_scale_projects.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Project owners can delete expert ratings"
  ON expert_ratings FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = expert_ratings.project_id
      AND sandbox_scale_projects.user_id = (select auth.uid())
    )
  );


-- CULTURAL_GROUPS
DROP POLICY IF EXISTS "Users can view own cultural groups" ON cultural_groups;
DROP POLICY IF EXISTS "Users can insert own cultural groups" ON cultural_groups;
DROP POLICY IF EXISTS "Users can update own cultural groups" ON cultural_groups;
DROP POLICY IF EXISTS "Users can delete own cultural groups" ON cultural_groups;

CREATE POLICY "Users can view own cultural groups"
  ON cultural_groups FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own cultural groups"
  ON cultural_groups FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own cultural groups"
  ON cultural_groups FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own cultural groups"
  ON cultural_groups FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- DIF_ANALYSES
DROP POLICY IF EXISTS "Users can view own DIF analyses" ON dif_analyses;
DROP POLICY IF EXISTS "Users can insert own DIF analyses" ON dif_analyses;
DROP POLICY IF EXISTS "Users can delete own DIF analyses" ON dif_analyses;

CREATE POLICY "Users can view own DIF analyses"
  ON dif_analyses FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own DIF analyses"
  ON dif_analyses FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own DIF analyses"
  ON dif_analyses FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- NOTIFICATIONS
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));


-- MESSAGES
DROP POLICY IF EXISTS "Users can view messages sent to them" ON messages;
DROP POLICY IF EXISTS "Users can send messages" ON messages;
DROP POLICY IF EXISTS "Users can update messages they received" ON messages;
DROP POLICY IF EXISTS "Users can delete messages they sent or received" ON messages;

CREATE POLICY "Users can view messages sent to them"
  ON messages FOR SELECT TO authenticated
  USING (to_user_id = (select auth.uid()) OR from_user_id = (select auth.uid()));

CREATE POLICY "Users can send messages"
  ON messages FOR INSERT TO authenticated
  WITH CHECK (from_user_id = (select auth.uid()));

CREATE POLICY "Users can update messages they received"
  ON messages FOR UPDATE TO authenticated
  USING (to_user_id = (select auth.uid()))
  WITH CHECK (to_user_id = (select auth.uid()));

CREATE POLICY "Users can delete messages they sent or received"
  ON messages FOR DELETE TO authenticated
  USING (from_user_id = (select auth.uid()) OR to_user_id = (select auth.uid()));


-- FORUM_POSTS
DROP POLICY IF EXISTS "Users can create forum posts" ON forum_posts;
DROP POLICY IF EXISTS "Users can update own forum posts" ON forum_posts;
DROP POLICY IF EXISTS "Users can delete own forum posts" ON forum_posts;
DROP POLICY IF EXISTS "Admins can pin posts" ON forum_posts;

CREATE POLICY "Users can create forum posts"
  ON forum_posts FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own forum posts"
  ON forum_posts FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own forum posts"
  ON forum_posts FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Admins can pin posts"
  ON forum_posts FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = (select auth.uid())
    )
  );


-- FORUM_REPLIES
DROP POLICY IF EXISTS "Users can create forum replies" ON forum_replies;
DROP POLICY IF EXISTS "Users can update own forum replies" ON forum_replies;
DROP POLICY IF EXISTS "Users can delete own forum replies" ON forum_replies;
DROP POLICY IF EXISTS "Post authors can mark solution" ON forum_replies;

CREATE POLICY "Users can create forum replies"
  ON forum_replies FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own forum replies"
  ON forum_replies FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own forum replies"
  ON forum_replies FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Post authors can mark solution"
  ON forum_replies FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM forum_posts
      WHERE forum_posts.id = forum_replies.post_id
      AND forum_posts.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM forum_posts
      WHERE forum_posts.id = forum_replies.post_id
      AND forum_posts.user_id = (select auth.uid())
    )
  );


-- USER_NOTIFICATION_PREFERENCES
DROP POLICY IF EXISTS "Users can view own preferences" ON user_notification_preferences;
DROP POLICY IF EXISTS "Users can insert own preferences" ON user_notification_preferences;
DROP POLICY IF EXISTS "Users can update own preferences" ON user_notification_preferences;

CREATE POLICY "Users can view own preferences"
  ON user_notification_preferences FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own preferences"
  ON user_notification_preferences FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own preferences"
  ON user_notification_preferences FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));


-- PLSSEM_MODELS
DROP POLICY IF EXISTS "Users can view own PLS-SEM models" ON plssem_models;
DROP POLICY IF EXISTS "Users can create own PLS-SEM models" ON plssem_models;
DROP POLICY IF EXISTS "Users can update own PLS-SEM models" ON plssem_models;
DROP POLICY IF EXISTS "Users can delete own PLS-SEM models" ON plssem_models;

CREATE POLICY "Users can view own PLS-SEM models"
  ON plssem_models FOR SELECT TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can create own PLS-SEM models"
  ON plssem_models FOR INSERT TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own PLS-SEM models"
  ON plssem_models FOR UPDATE TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own PLS-SEM models"
  ON plssem_models FOR DELETE TO authenticated
  USING (user_id = (select auth.uid()));

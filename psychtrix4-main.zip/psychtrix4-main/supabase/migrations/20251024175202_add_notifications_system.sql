/*
  # Notifications and Messages System

  ## Overview
  This migration creates a comprehensive notification system for tracking user updates, messages,
  and forum activity. It supports both user-to-user and admin-to-user notifications.

  ## New Tables
  
  ### `notifications`
  - `id` (uuid, primary key) - Unique notification identifier
  - `user_id` (uuid, foreign key) - Recipient user
  - `type` (text) - Notification type: 'message', 'forum_reply', 'system', 'analysis_complete', 'report_ready', 'share_request'
  - `title` (text) - Notification title
  - `message` (text) - Notification content
  - `link` (text, nullable) - Optional deep link to relevant page
  - `related_id` (uuid, nullable) - ID of related entity (message, forum post, etc.)
  - `read` (boolean) - Whether notification has been read
  - `created_at` (timestamptz) - When notification was created
  - `read_at` (timestamptz, nullable) - When notification was read

  ### `messages`
  - `id` (uuid, primary key) - Unique message identifier
  - `from_user_id` (uuid, foreign key) - Sender
  - `to_user_id` (uuid, foreign key) - Recipient
  - `subject` (text) - Message subject
  - `body` (text) - Message content
  - `read` (boolean) - Whether message has been read
  - `parent_message_id` (uuid, nullable) - For message threading/replies
  - `created_at` (timestamptz) - When message was sent
  - `read_at` (timestamptz, nullable) - When message was read

  ### `forum_posts`
  - `id` (uuid, primary key) - Unique post identifier
  - `user_id` (uuid, foreign key) - Post author
  - `title` (text) - Post title
  - `body` (text) - Post content
  - `category` (text) - Post category: 'general', 'help', 'feature_request', 'bug_report', 'discussion'
  - `status` (text) - Post status: 'open', 'answered', 'closed'
  - `reply_count` (integer) - Number of replies
  - `last_activity_at` (timestamptz) - Last activity timestamp
  - `created_at` (timestamptz) - When post was created
  - `updated_at` (timestamptz) - When post was last updated

  ### `forum_replies`
  - `id` (uuid, primary key) - Unique reply identifier
  - `post_id` (uuid, foreign key) - Parent post
  - `user_id` (uuid, foreign key) - Reply author
  - `body` (text) - Reply content
  - `is_admin_reply` (boolean) - Whether reply is from admin
  - `created_at` (timestamptz) - When reply was created
  - `updated_at` (timestamptz) - When reply was updated

  ## Security
  - Enable RLS on all tables
  - Users can read their own notifications
  - Users can send/receive messages
  - Users can create/read forum posts and replies
  - Admin users have broader access

  ## Indexes
  - Index on user_id and read status for fast notification queries
  - Index on message recipient and read status
  - Index on forum posts by category and status
*/

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('message', 'forum_reply', 'system', 'analysis_complete', 'report_ready', 'share_request')),
  title text NOT NULL,
  message text NOT NULL,
  link text,
  related_id uuid,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  to_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subject text NOT NULL,
  body text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  parent_message_id uuid REFERENCES messages(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz
);

-- Create forum_posts table
CREATE TABLE IF NOT EXISTS forum_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text NOT NULL,
  category text NOT NULL DEFAULT 'general' CHECK (category IN ('general', 'help', 'feature_request', 'bug_report', 'discussion')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'answered', 'closed')),
  reply_count integer NOT NULL DEFAULT 0,
  last_activity_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create forum_replies table
CREATE TABLE IF NOT EXISTS forum_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL,
  is_admin_reply boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_replies ENABLE ROW LEVEL SECURITY;

-- Notifications policies
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "System can create notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Messages policies
CREATE POLICY "Users can view messages sent to them"
  ON messages FOR SELECT
  TO authenticated
  USING (auth.uid() = to_user_id OR auth.uid() = from_user_id);

CREATE POLICY "Users can send messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = from_user_id);

CREATE POLICY "Users can update messages they received"
  ON messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = to_user_id)
  WITH CHECK (auth.uid() = to_user_id);

CREATE POLICY "Users can delete messages they sent or received"
  ON messages FOR DELETE
  TO authenticated
  USING (auth.uid() = from_user_id OR auth.uid() = to_user_id);

-- Forum posts policies
CREATE POLICY "Anyone can view forum posts"
  ON forum_posts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create forum posts"
  ON forum_posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own forum posts"
  ON forum_posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own forum posts"
  ON forum_posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Forum replies policies
CREATE POLICY "Anyone can view forum replies"
  ON forum_replies FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create forum replies"
  ON forum_replies FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own forum replies"
  ON forum_replies FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own forum replies"
  ON forum_replies FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread 
  ON notifications(user_id, read, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_messages_recipient_unread 
  ON messages(to_user_id, read, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_messages_sender 
  ON messages(from_user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_forum_posts_category_status 
  ON forum_posts(category, status, last_activity_at DESC);

CREATE INDEX IF NOT EXISTS idx_forum_replies_post 
  ON forum_replies(post_id, created_at ASC);

-- Create function to update forum post reply count and last activity
CREATE OR REPLACE FUNCTION update_forum_post_stats()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum_posts
    SET reply_count = reply_count + 1,
        last_activity_at = NEW.created_at,
        updated_at = NEW.created_at
    WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum_posts
    SET reply_count = GREATEST(0, reply_count - 1),
        updated_at = now()
    WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for forum post stats
DROP TRIGGER IF EXISTS update_forum_stats_trigger ON forum_replies;
CREATE TRIGGER update_forum_stats_trigger
  AFTER INSERT OR DELETE ON forum_replies
  FOR EACH ROW
  EXECUTE FUNCTION update_forum_post_stats();

-- Create function to create notification on new forum reply
CREATE OR REPLACE FUNCTION create_reply_notification()
RETURNS TRIGGER AS $$
DECLARE
  post_author_id uuid;
  post_title text;
BEGIN
  SELECT user_id, title INTO post_author_id, post_title
  FROM forum_posts
  WHERE id = NEW.post_id;
  
  IF post_author_id != NEW.user_id THEN
    INSERT INTO notifications (user_id, type, title, message, link, related_id)
    VALUES (
      post_author_id,
      'forum_reply',
      'New reply on your post',
      'Someone replied to your post: ' || post_title,
      '/help',
      NEW.post_id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for reply notifications
DROP TRIGGER IF EXISTS create_reply_notification_trigger ON forum_replies;
CREATE TRIGGER create_reply_notification_trigger
  AFTER INSERT ON forum_replies
  FOR EACH ROW
  EXECUTE FUNCTION create_reply_notification();

-- Create function to create notification on new message
CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, link, related_id)
  VALUES (
    NEW.to_user_id,
    'message',
    'New message: ' || NEW.subject,
    LEFT(NEW.body, 100),
    '/settings',
    NEW.id
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for message notifications
DROP TRIGGER IF EXISTS create_message_notification_trigger ON messages;
CREATE TRIGGER create_message_notification_trigger
  AFTER INSERT ON messages
  FOR EACH ROW
  EXECUTE FUNCTION create_message_notification();
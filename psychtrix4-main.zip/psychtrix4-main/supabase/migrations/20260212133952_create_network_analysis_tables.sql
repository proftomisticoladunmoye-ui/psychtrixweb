/*
  # Create Network Analysis System

  1. New Tables
    - `network_projects`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text) - Project name
      - `description` (text) - Project description
      - `data_type` (text) - continuous, binary, mixed
      - `estimation_method` (text) - ebicglasso, ising, etc
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `network_datasets`
      - `id` (uuid, primary key)
      - `project_id` (uuid, foreign key to network_projects)
      - `name` (text) - Dataset name
      - `variables` (jsonb) - Variable names and metadata
      - `raw_data` (jsonb) - Stored data matrix
      - `sample_size` (integer)
      - `created_at` (timestamptz)

    - `network_estimations`
      - `id` (uuid, primary key)
      - `project_id` (uuid, foreign key to network_projects)
      - `dataset_id` (uuid, foreign key to network_datasets)
      - `method` (text) - ebicglasso, ising, etc
      - `parameters` (jsonb) - Estimation parameters
      - `edge_weights` (jsonb) - Network adjacency matrix
      - `node_positions` (jsonb) - Layout positions
      - `created_at` (timestamptz)

    - `network_centrality`
      - `id` (uuid, primary key)
      - `estimation_id` (uuid, foreign key to network_estimations)
      - `node_name` (text)
      - `strength` (numeric)
      - `betweenness` (numeric)
      - `closeness` (numeric)
      - `expected_influence` (numeric)
      - `bridge_strength` (numeric)

    - `network_stability`
      - `id` (uuid, primary key)
      - `estimation_id` (uuid, foreign key to network_estimations)
      - `metric` (text) - edge_accuracy, centrality_stability
      - `results` (jsonb) - Bootstrap results
      - `cs_coefficient` (numeric) - Correlation stability coefficient
      - `created_at` (timestamptz)

    - `network_communities`
      - `id` (uuid, primary key)
      - `estimation_id` (uuid, foreign key to network_estimations)
      - `algorithm` (text) - walktrap, louvain
      - `communities` (jsonb) - Node-community assignments
      - `modularity` (numeric)
      - `created_at` (timestamptz)

    - `network_comparisons`
      - `id` (uuid, primary key)
      - `project_id` (uuid, foreign key to network_projects)
      - `estimation_id_1` (uuid, foreign key)
      - `estimation_id_2` (uuid, foreign key)
      - `nct_results` (jsonb) - NCT test results
      - `global_strength_diff` (numeric)
      - `edge_differences` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can only access their own network projects

  3. Indexes
    - Performance indexes on foreign keys
    - Index on project_id for quick lookups
*/

-- Create network_projects table
CREATE TABLE IF NOT EXISTS network_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text DEFAULT '',
  data_type text DEFAULT 'continuous' CHECK (data_type IN ('continuous', 'binary', 'mixed')),
  estimation_method text DEFAULT 'ebicglasso',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create network_datasets table
CREATE TABLE IF NOT EXISTS network_datasets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES network_projects(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  variables jsonb NOT NULL DEFAULT '[]',
  raw_data jsonb NOT NULL DEFAULT '[]',
  sample_size integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create network_estimations table
CREATE TABLE IF NOT EXISTS network_estimations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES network_projects(id) ON DELETE CASCADE NOT NULL,
  dataset_id uuid REFERENCES network_datasets(id) ON DELETE CASCADE,
  method text NOT NULL,
  parameters jsonb DEFAULT '{}',
  edge_weights jsonb NOT NULL DEFAULT '{}',
  node_positions jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create network_centrality table
CREATE TABLE IF NOT EXISTS network_centrality (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  estimation_id uuid REFERENCES network_estimations(id) ON DELETE CASCADE NOT NULL,
  node_name text NOT NULL,
  strength numeric DEFAULT 0,
  betweenness numeric DEFAULT 0,
  closeness numeric DEFAULT 0,
  expected_influence numeric DEFAULT 0,
  bridge_strength numeric DEFAULT 0
);

-- Create network_stability table
CREATE TABLE IF NOT EXISTS network_stability (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  estimation_id uuid REFERENCES network_estimations(id) ON DELETE CASCADE NOT NULL,
  metric text NOT NULL,
  results jsonb NOT NULL DEFAULT '{}',
  cs_coefficient numeric,
  created_at timestamptz DEFAULT now()
);

-- Create network_communities table
CREATE TABLE IF NOT EXISTS network_communities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  estimation_id uuid REFERENCES network_estimations(id) ON DELETE CASCADE NOT NULL,
  algorithm text NOT NULL,
  communities jsonb NOT NULL DEFAULT '{}',
  modularity numeric DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create network_comparisons table
CREATE TABLE IF NOT EXISTS network_comparisons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES network_projects(id) ON DELETE CASCADE NOT NULL,
  estimation_id_1 uuid REFERENCES network_estimations(id) ON DELETE CASCADE,
  estimation_id_2 uuid REFERENCES network_estimations(id) ON DELETE CASCADE,
  nct_results jsonb NOT NULL DEFAULT '{}',
  global_strength_diff numeric,
  edge_differences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_network_projects_user ON network_projects(user_id);
CREATE INDEX IF NOT EXISTS idx_network_datasets_project ON network_datasets(project_id);
CREATE INDEX IF NOT EXISTS idx_network_estimations_project ON network_estimations(project_id);
CREATE INDEX IF NOT EXISTS idx_network_estimations_dataset ON network_estimations(dataset_id);
CREATE INDEX IF NOT EXISTS idx_network_centrality_estimation ON network_centrality(estimation_id);
CREATE INDEX IF NOT EXISTS idx_network_stability_estimation ON network_stability(estimation_id);
CREATE INDEX IF NOT EXISTS idx_network_communities_estimation ON network_communities(estimation_id);
CREATE INDEX IF NOT EXISTS idx_network_comparisons_project ON network_comparisons(project_id);

-- Enable Row Level Security
ALTER TABLE network_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_datasets ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_estimations ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_centrality ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_stability ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_communities ENABLE ROW LEVEL SECURITY;
ALTER TABLE network_comparisons ENABLE ROW LEVEL SECURITY;

-- RLS Policies for network_projects
CREATE POLICY "Users can view own network projects"
  ON network_projects FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own network projects"
  ON network_projects FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own network projects"
  ON network_projects FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own network projects"
  ON network_projects FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for network_datasets
CREATE POLICY "Users can view datasets in their projects"
  ON network_datasets FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_datasets.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create datasets in their projects"
  ON network_datasets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_datasets.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update datasets in their projects"
  ON network_datasets FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_datasets.project_id
      AND network_projects.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_datasets.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete datasets in their projects"
  ON network_datasets FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_datasets.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

-- RLS Policies for network_estimations
CREATE POLICY "Users can view estimations in their projects"
  ON network_estimations FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_estimations.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create estimations in their projects"
  ON network_estimations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_estimations.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update estimations in their projects"
  ON network_estimations FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_estimations.project_id
      AND network_projects.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_estimations.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete estimations in their projects"
  ON network_estimations FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_estimations.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

-- RLS Policies for network_centrality
CREATE POLICY "Users can view centrality in their estimations"
  ON network_centrality FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_centrality.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create centrality in their estimations"
  ON network_centrality FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_centrality.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update centrality in their estimations"
  ON network_centrality FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_centrality.estimation_id
      AND np.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_centrality.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete centrality in their estimations"
  ON network_centrality FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_centrality.estimation_id
      AND np.user_id = auth.uid()
    )
  );

-- RLS Policies for network_stability
CREATE POLICY "Users can view stability in their estimations"
  ON network_stability FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_stability.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create stability in their estimations"
  ON network_stability FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_stability.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update stability in their estimations"
  ON network_stability FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_stability.estimation_id
      AND np.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_stability.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete stability in their estimations"
  ON network_stability FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_stability.estimation_id
      AND np.user_id = auth.uid()
    )
  );

-- RLS Policies for network_communities
CREATE POLICY "Users can view communities in their estimations"
  ON network_communities FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_communities.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create communities in their estimations"
  ON network_communities FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_communities.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update communities in their estimations"
  ON network_communities FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_communities.estimation_id
      AND np.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_communities.estimation_id
      AND np.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete communities in their estimations"
  ON network_communities FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_estimations ne
      JOIN network_projects np ON np.id = ne.project_id
      WHERE ne.id = network_communities.estimation_id
      AND np.user_id = auth.uid()
    )
  );

-- RLS Policies for network_comparisons
CREATE POLICY "Users can view comparisons in their projects"
  ON network_comparisons FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_comparisons.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create comparisons in their projects"
  ON network_comparisons FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_comparisons.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update comparisons in their projects"
  ON network_comparisons FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_comparisons.project_id
      AND network_projects.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_comparisons.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete comparisons in their projects"
  ON network_comparisons FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM network_projects
      WHERE network_projects.id = network_comparisons.project_id
      AND network_projects.user_id = auth.uid()
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_network_project_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for updated_at
CREATE TRIGGER update_network_projects_updated_at
  BEFORE UPDATE ON network_projects
  FOR EACH ROW
  EXECUTE FUNCTION update_network_project_updated_at();

/*
  # Create CAT (Computerized Adaptive Testing) System

  1. New Tables
    - `cat_item_banks`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text) - Name of the item bank
      - `description` (text) - Description
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `cat_items`
      - `id` (uuid, primary key)
      - `item_bank_id` (uuid, foreign key to cat_item_banks)
      - `content` (text) - Item question/statement
      - `a_param` (numeric) - Discrimination parameter
      - `b_param` (numeric) - Difficulty parameter
      - `c_param` (numeric) - Guessing parameter
      - `content_category` (text) - Content classification
      - `exposure_count` (integer) - Times administered
      - `created_at` (timestamptz)

    - `cat_sessions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `item_bank_id` (uuid, foreign key to cat_item_banks)
      - `configuration` (jsonb) - CAT settings used
      - `final_theta` (numeric) - Final ability estimate
      - `final_se` (numeric) - Final standard error
      - `total_items` (integer) - Items administered
      - `test_duration` (numeric) - Duration in seconds
      - `stopping_reason` (text)
      - `status` (text) - idle, running, completed
      - `started_at` (timestamptz)
      - `completed_at` (timestamptz)
      - `created_at` (timestamptz)

    - `cat_session_responses`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key to cat_sessions)
      - `item_id` (uuid, foreign key to cat_items)
      - `item_number` (integer) - Sequence in test
      - `response` (integer) - 0 or 1
      - `theta_before` (numeric) - Ability before response
      - `theta_after` (numeric) - Ability after response
      - `se_before` (numeric)
      - `se_after` (numeric)
      - `information` (numeric) - Item information
      - `response_time` (numeric) - Time in seconds
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can only access their own data
    - Item banks can be shared (future feature)

  3. Indexes
    - Performance indexes on foreign keys
    - Index on exposure_count for item selection
*/

-- Create cat_item_banks table
CREATE TABLE IF NOT EXISTS cat_item_banks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create cat_items table
CREATE TABLE IF NOT EXISTS cat_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_bank_id uuid REFERENCES cat_item_banks(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  a_param numeric NOT NULL CHECK (a_param > 0),
  b_param numeric NOT NULL CHECK (b_param BETWEEN -4 AND 4),
  c_param numeric NOT NULL CHECK (c_param >= 0 AND c_param < 1),
  content_category text DEFAULT 'General',
  exposure_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create cat_sessions table
CREATE TABLE IF NOT EXISTS cat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  item_bank_id uuid REFERENCES cat_item_banks(id) ON DELETE SET NULL,
  configuration jsonb DEFAULT '{}',
  final_theta numeric,
  final_se numeric,
  total_items integer DEFAULT 0,
  test_duration numeric,
  stopping_reason text,
  status text DEFAULT 'idle' CHECK (status IN ('idle', 'running', 'completed', 'paused')),
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create cat_session_responses table
CREATE TABLE IF NOT EXISTS cat_session_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES cat_sessions(id) ON DELETE CASCADE NOT NULL,
  item_id uuid REFERENCES cat_items(id) ON DELETE SET NULL,
  item_number integer NOT NULL,
  response integer NOT NULL CHECK (response IN (0, 1)),
  theta_before numeric,
  theta_after numeric,
  se_before numeric,
  se_after numeric,
  information numeric,
  response_time numeric,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_cat_items_bank ON cat_items(item_bank_id);
CREATE INDEX IF NOT EXISTS idx_cat_items_exposure ON cat_items(exposure_count);
CREATE INDEX IF NOT EXISTS idx_cat_items_category ON cat_items(content_category);
CREATE INDEX IF NOT EXISTS idx_cat_sessions_user ON cat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_cat_sessions_bank ON cat_sessions(item_bank_id);
CREATE INDEX IF NOT EXISTS idx_cat_session_responses_session ON cat_session_responses(session_id);
CREATE INDEX IF NOT EXISTS idx_cat_session_responses_item ON cat_session_responses(item_id);

-- Enable Row Level Security
ALTER TABLE cat_item_banks ENABLE ROW LEVEL SECURITY;
ALTER TABLE cat_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE cat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE cat_session_responses ENABLE ROW LEVEL SECURITY;

-- RLS Policies for cat_item_banks
CREATE POLICY "Users can view own item banks"
  ON cat_item_banks FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own item banks"
  ON cat_item_banks FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own item banks"
  ON cat_item_banks FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own item banks"
  ON cat_item_banks FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for cat_items
CREATE POLICY "Users can view items in their banks"
  ON cat_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cat_item_banks
      WHERE cat_item_banks.id = cat_items.item_bank_id
      AND cat_item_banks.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create items in their banks"
  ON cat_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM cat_item_banks
      WHERE cat_item_banks.id = cat_items.item_bank_id
      AND cat_item_banks.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update items in their banks"
  ON cat_items FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cat_item_banks
      WHERE cat_item_banks.id = cat_items.item_bank_id
      AND cat_item_banks.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM cat_item_banks
      WHERE cat_item_banks.id = cat_items.item_bank_id
      AND cat_item_banks.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete items in their banks"
  ON cat_items FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cat_item_banks
      WHERE cat_item_banks.id = cat_items.item_bank_id
      AND cat_item_banks.user_id = auth.uid()
    )
  );

-- RLS Policies for cat_sessions
CREATE POLICY "Users can view own sessions"
  ON cat_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own sessions"
  ON cat_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
  ON cat_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own sessions"
  ON cat_sessions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for cat_session_responses
CREATE POLICY "Users can view responses from their sessions"
  ON cat_session_responses FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cat_sessions
      WHERE cat_sessions.id = cat_session_responses.session_id
      AND cat_sessions.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create responses in their sessions"
  ON cat_session_responses FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM cat_sessions
      WHERE cat_sessions.id = cat_session_responses.session_id
      AND cat_sessions.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update responses in their sessions"
  ON cat_session_responses FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cat_sessions
      WHERE cat_sessions.id = cat_session_responses.session_id
      AND cat_sessions.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM cat_sessions
      WHERE cat_sessions.id = cat_session_responses.session_id
      AND cat_sessions.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete responses in their sessions"
  ON cat_session_responses FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cat_sessions
      WHERE cat_sessions.id = cat_session_responses.session_id
      AND cat_sessions.user_id = auth.uid()
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_cat_item_bank_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for updated_at
CREATE TRIGGER update_cat_item_banks_updated_at
  BEFORE UPDATE ON cat_item_banks
  FOR EACH ROW
  EXECUTE FUNCTION update_cat_item_bank_updated_at();

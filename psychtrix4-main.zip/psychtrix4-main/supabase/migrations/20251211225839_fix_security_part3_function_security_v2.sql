/*
  # Fix Security Issues - Part 3: Fix Function Security (v2)

  Updates all database functions to have proper `search_path` security settings
  to prevent search path vulnerabilities.

  ## Functions Updated
  - update_updated_at_column
  - update_last_modified_column
  - update_forum_post_stats
  - increment_forum_post_views
  - get_user_email
  - set_forum_post_user_email
  - set_forum_reply_user_email
  - create_reply_notification
  - create_message_notification
  - get_user_notification_prefs
  - queue_email_notification
  - notify_post_author_on_reply
  - notify_on_solution_marked
  - notify_on_admin_reply
*/

-- Drop functions that may have signature changes
DROP FUNCTION IF EXISTS get_user_notification_prefs(uuid);
DROP FUNCTION IF EXISTS queue_email_notification(uuid, text, text, text);

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_last_modified_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.last_modified = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_forum_post_stats()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum_posts
    SET reply_count = reply_count + 1,
        last_activity_at = now(),
        updated_at = now()
    WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum_posts
    SET reply_count = GREATEST(0, reply_count - 1),
        updated_at = now()
    WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION increment_forum_post_views()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE forum_posts
  SET views_count = views_count + 1
  WHERE id = NEW.id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION get_user_email(user_uuid uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  user_email text;
BEGIN
  SELECT email INTO user_email
  FROM auth.users
  WHERE id = user_uuid;
  RETURN user_email;
END;
$$;

CREATE OR REPLACE FUNCTION set_forum_post_user_email()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.user_email := get_user_email(NEW.user_id);
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION set_forum_reply_user_email()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.user_email := get_user_email(NEW.user_id);
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION create_reply_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  post_author_id uuid;
  post_title text;
BEGIN
  SELECT user_id, title INTO post_author_id, post_title
  FROM forum_posts
  WHERE id = NEW.post_id;
  
  IF post_author_id IS NOT NULL AND post_author_id != NEW.user_id THEN
    INSERT INTO notifications (user_id, type, title, message, link, related_id)
    VALUES (
      post_author_id,
      'forum_reply',
      'New reply on your post',
      'Someone replied to your post: ' || post_title,
      '/help',
      NEW.post_id
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, link, related_id)
  VALUES (
    NEW.to_user_id,
    'message',
    'New message: ' || NEW.subject,
    LEFT(NEW.body, 100),
    '/settings',
    NEW.id
  );
  RETURN NEW;
END;
$$;

CREATE FUNCTION get_user_notification_prefs(user_uuid uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  prefs jsonb;
BEGIN
  SELECT row_to_json(p)::jsonb INTO prefs
  FROM user_notification_preferences p
  WHERE p.user_id = user_uuid;
  
  IF prefs IS NULL THEN
    RETURN jsonb_build_object(
      'email_on_reply', true,
      'email_on_solution', true,
      'email_on_admin_reply', true,
      'email_daily_digest', false,
      'email_weekly_digest', true
    );
  END IF;
  
  RETURN prefs;
END;
$$;

CREATE FUNCTION queue_email_notification(
  recipient_uuid uuid,
  email_type text,
  subject_text text,
  body_text text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  recipient_email_addr text;
BEGIN
  SELECT email INTO recipient_email_addr
  FROM auth.users
  WHERE id = recipient_uuid;
  
  IF recipient_email_addr IS NOT NULL THEN
    INSERT INTO email_queue (
      user_id,
      recipient_email,
      notification_type,
      subject,
      body
    ) VALUES (
      recipient_uuid,
      recipient_email_addr,
      email_type,
      subject_text,
      body_text
    );
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION notify_post_author_on_reply()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  post_author_id uuid;
  post_title text;
  prefs jsonb;
BEGIN
  SELECT user_id, title INTO post_author_id, post_title
  FROM forum_posts
  WHERE id = NEW.post_id;
  
  IF post_author_id IS NOT NULL AND post_author_id != NEW.user_id THEN
    prefs := get_user_notification_prefs(post_author_id);
    
    IF (prefs->>'email_on_reply')::boolean THEN
      PERFORM queue_email_notification(
        post_author_id,
        'reply',
        'New reply to your post: ' || post_title,
        'Someone replied to your post "' || post_title || '"'
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION notify_on_solution_marked()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  post_title text;
  prefs jsonb;
BEGIN
  IF NEW.is_solution = true AND (OLD.is_solution IS NULL OR OLD.is_solution = false) THEN
    SELECT title INTO post_title
    FROM forum_posts
    WHERE id = NEW.post_id;
    
    IF NEW.user_id IS NOT NULL THEN
      prefs := get_user_notification_prefs(NEW.user_id);
      
      IF (prefs->>'email_on_solution')::boolean THEN
        PERFORM queue_email_notification(
          NEW.user_id,
          'solution',
          'Your reply was marked as solution',
          'Your reply to "' || post_title || '" was marked as the solution'
        );
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION notify_on_admin_reply()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_admin boolean;
  post_author_id uuid;
  post_title text;
  prefs jsonb;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM forum_admins WHERE user_id = NEW.user_id
  ) INTO is_admin;
  
  IF is_admin THEN
    SELECT user_id, title INTO post_author_id, post_title
    FROM forum_posts
    WHERE id = NEW.post_id;
    
    IF post_author_id IS NOT NULL AND post_author_id != NEW.user_id THEN
      prefs := get_user_notification_prefs(post_author_id);
      
      IF (prefs->>'email_on_admin_reply')::boolean THEN
        PERFORM queue_email_notification(
          post_author_id,
          'admin_reply',
          'Admin replied to your post',
          'An admin replied to your post "' || post_title || '"'
        );
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

/*
  # Add Path Analysis Templates

  1. Templates Added
    - Simple Path Model (lavaan)
    - Mediation Analysis (lavaan with bootstrap)
    - Moderation Analysis (lavaan with interaction terms)
    - Parallel Mediation (multiple mediators)
    - Serial Mediation (chained mediators)
    - Moderated Mediation (conditional process)

  2. Features
    - Direct, indirect, and total effects
    - Bootstrap confidence intervals
    - Standardized and unstandardized coefficients
    - R-squared for endogenous variables
    - Path diagrams via semPlot
    - Sobel test and bootstrapped indirect effects
    - Simple slopes for moderation
*/

-- Insert Path Analysis templates
INSERT INTO r_analysis_templates (template_name, job_type, r_script_template, required_packages, description) VALUES
(
  'path_simple_model',
  'path',
  '# Simple Path Analysis using lavaan
library(lavaan)
library(jsonlite)
library(semPlot)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_df <- as.data.frame(input$data)
colnames(data_df) <- input$variables

# Extract parameters
iv <- "{{IV_VARIABLE}}"
dv <- "{{DV_VARIABLE}}"
covariates <- fromJSON(''{{COVARIATES}}'')

# Build model syntax
model_syntax <- paste0(dv, " ~ ", iv)
if (length(covariates) > 0 && covariates[1] != "") {
  model_syntax <- paste0(model_syntax, " + ", paste(covariates, collapse = " + "))
}

# Fit model
fit <- sem(model_syntax, data = data_df, se = "bootstrap", bootstrap = 1000)

# Extract results
params <- parameterEstimates(fit, boot.ci.type = "perc", standardized = TRUE)
fit_measures <- fitMeasures(fit, c("chisq", "df", "pvalue", "cfi", "tli", "rmsea", "srmr"))
r_squared <- inspect(fit, "r2")

# Generate path diagram
png("path_diagram.png", width = 1000, height = 800, res = 150)
semPaths(fit, what = "est", layout = "tree", edge.label.cex = 1.2,
         style = "lisrel", curve = 1, nCharNodes = 0,
         sizeMan = 10, sizeLat = 12, edge.color = "black",
         label.cex = 1.2, residuals = TRUE, intercepts = FALSE)
dev.off()

# Prepare results
results <- list(
  model_type = "simple_path",
  parameters = params,
  fit_measures = as.list(fit_measures),
  r_squared = r_squared,
  model_syntax = model_syntax,
  standardized_solution = standardizedSolution(fit)
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["lavaan", "jsonlite", "semPlot"]',
  'Simple path analysis with direct effects'
),
(
  'path_mediation_model',
  'path',
  '# Mediation Analysis using lavaan
library(lavaan)
library(jsonlite)
library(semPlot)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_df <- as.data.frame(input$data)
colnames(data_df) <- input$variables

# Extract parameters
iv <- "{{IV_VARIABLE}}"
mediator <- "{{MEDIATOR_VARIABLE}}"
dv <- "{{DV_VARIABLE}}"
covariates <- fromJSON(''{{COVARIATES}}'')

# Build mediation model
cov_string <- ""
if (length(covariates) > 0 && covariates[1] != "") {
  cov_string <- paste0(" + ", paste(covariates, collapse = " + "))
}

model_syntax <- paste0(
  "# Direct effect (c path)\n",
  dv, " ~ c*", iv, cov_string, "\n",
  "# a path (IV to Mediator)\n",
  mediator, " ~ a*", iv, cov_string, "\n",
  "# b path (Mediator to DV)\n",
  dv, " ~ b*", mediator, "\n",
  "# Indirect effect\n",
  "indirect := a*b\n",
  "# Total effect\n",
  "total := c + (a*b)\n"
)

# Fit model with bootstrap
fit <- sem(model_syntax, data = data_df, se = "bootstrap", bootstrap = 5000)

# Extract results
params <- parameterEstimates(fit, boot.ci.type = "perc", standardized = TRUE)
fit_measures <- fitMeasures(fit, c("chisq", "df", "pvalue", "cfi", "tli", "rmsea", "srmr"))
r_squared <- inspect(fit, "r2")

# Extract specific effects
indirect_effect <- params[params$label == "indirect", ]
total_effect <- params[params$label == "total", ]
direct_effect <- params[params$label == "c", ]
a_path <- params[params$label == "a", ]
b_path <- params[params$label == "b", ]

# Generate path diagram
png("mediation_diagram.png", width = 1200, height = 800, res = 150)
semPaths(fit, what = "est", layout = "tree2", edge.label.cex = 1.1,
         style = "lisrel", curve = 1.5, nCharNodes = 0,
         sizeMan = 10, sizeLat = 12, edge.color = "black",
         label.cex = 1.1, residuals = TRUE, intercepts = FALSE,
         rotation = 2)
title("Mediation Model", line = 3, cex.main = 1.3)
dev.off()

# Prepare results
results <- list(
  model_type = "mediation",
  indirect_effect = list(
    estimate = indirect_effect$est,
    se = indirect_effect$se,
    z = indirect_effect$z,
    pvalue = indirect_effect$pvalue,
    ci_lower = indirect_effect$ci.lower,
    ci_upper = indirect_effect$ci.upper,
    std = indirect_effect$std.all
  ),
  direct_effect = list(
    estimate = direct_effect$est,
    se = direct_effect$se,
    z = direct_effect$z,
    pvalue = direct_effect$pvalue,
    ci_lower = direct_effect$ci.lower,
    ci_upper = direct_effect$ci.upper,
    std = direct_effect$std.all
  ),
  total_effect = list(
    estimate = total_effect$est,
    se = total_effect$se,
    z = total_effect$z,
    pvalue = total_effect$pvalue,
    ci_lower = total_effect$ci.lower,
    ci_upper = total_effect$ci.upper,
    std = total_effect$std.all
  ),
  a_path = list(
    estimate = a_path$est,
    se = a_path$se,
    z = a_path$z,
    pvalue = a_path$pvalue,
    std = a_path$std.all
  ),
  b_path = list(
    estimate = b_path$est,
    se = b_path$se,
    z = b_path$z,
    pvalue = b_path$pvalue,
    std = b_path$std.all
  ),
  proportion_mediated = abs(indirect_effect$est / total_effect$est),
  all_parameters = params,
  fit_measures = as.list(fit_measures),
  r_squared = r_squared,
  model_syntax = model_syntax
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["lavaan", "jsonlite", "semPlot"]',
  'Mediation analysis with bootstrapped indirect effects'
),
(
  'path_moderation_model',
  'path',
  '# Moderation Analysis using lavaan
library(lavaan)
library(jsonlite)
library(semPlot)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_df <- as.data.frame(input$data)
colnames(data_df) <- input$variables

# Extract parameters
iv <- "{{IV_VARIABLE}}"
moderator <- "{{MODERATOR_VARIABLE}}"
dv <- "{{DV_VARIABLE}}"
covariates <- fromJSON(''{{COVARIATES}}'')

# Center variables for interaction
data_df[[paste0(iv, "_c")]] <- scale(data_df[[iv]], scale = FALSE)
data_df[[paste0(moderator, "_c")]] <- scale(data_df[[moderator]], scale = FALSE)
data_df$interaction <- data_df[[paste0(iv, "_c")]] * data_df[[paste0(moderator, "_c")]]

# Build model
cov_string <- ""
if (length(covariates) > 0 && covariates[1] != "") {
  cov_string <- paste0(" + ", paste(covariates, collapse = " + "))
}

iv_c <- paste0(iv, "_c")
mod_c <- paste0(moderator, "_c")

model_syntax <- paste0(
  dv, " ~ b1*", iv_c, " + b2*", mod_c, " + b3*interaction", cov_string
)

# Fit model
fit <- sem(model_syntax, data = data_df, se = "bootstrap", bootstrap = 1000)

# Extract results
params <- parameterEstimates(fit, boot.ci.type = "perc", standardized = TRUE)
fit_measures <- fitMeasures(fit, c("chisq", "df", "pvalue", "rmsea", "srmr"))
r_squared <- inspect(fit, "r2")

# Calculate simple slopes
mod_mean <- mean(data_df[[moderator]], na.rm = TRUE)
mod_sd <- sd(data_df[[moderator]], na.rm = TRUE)
mod_low <- mod_mean - mod_sd
mod_high <- mod_mean + mod_sd

b1_est <- params[params$label == "b1", "est"]
b3_est <- params[params$label == "b3", "est"]

slope_low <- b1_est + b3_est * (-mod_sd)
slope_mean <- b1_est + b3_est * 0
slope_high <- b1_est + b3_est * mod_sd

# Generate interaction plot
png("moderation_plot.png", width = 1000, height = 800, res = 150)
iv_range <- seq(min(data_df[[iv_c]], na.rm = TRUE),
                max(data_df[[iv_c]], na.rm = TRUE),
                length.out = 100)

plot(iv_range, slope_low * iv_range, type = "l", lwd = 2, col = "blue",
     xlab = paste(iv, "(centered)"), ylab = dv,
     main = "Moderation Effect", ylim = c(min(slope_low * iv_range),
                                          max(slope_high * iv_range)))
lines(iv_range, slope_mean * iv_range, lwd = 2, col = "black")
lines(iv_range, slope_high * iv_range, lwd = 2, col = "red")
legend("topleft", legend = c("Low Moderator (-1 SD)", "Mean Moderator",
                             "High Moderator (+1 SD)"),
       col = c("blue", "black", "red"), lwd = 2)
grid()
dev.off()

# Prepare results
results <- list(
  model_type = "moderation",
  interaction_effect = params[params$label == "b3", ],
  main_effect_iv = params[params$label == "b1", ],
  main_effect_mod = params[params$label == "b2", ],
  simple_slopes = list(
    low = list(moderator_value = mod_low, slope = slope_low),
    mean = list(moderator_value = mod_mean, slope = slope_mean),
    high = list(moderator_value = mod_high, slope = slope_high)
  ),
  all_parameters = params,
  fit_measures = as.list(fit_measures),
  r_squared = r_squared,
  model_syntax = model_syntax
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["lavaan", "jsonlite", "semPlot"]',
  'Moderation analysis with interaction effects and simple slopes'
),
(
  'path_parallel_mediation',
  'path',
  '# Parallel Mediation Analysis
library(lavaan)
library(jsonlite)
library(semPlot)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_df <- as.data.frame(input$data)
colnames(data_df) <- input$variables

# Extract parameters
iv <- "{{IV_VARIABLE}}"
mediators <- fromJSON(''{{MEDIATORS}}'')
dv <- "{{DV_VARIABLE}}"

# Build parallel mediation model
a_paths <- paste0("a", 1:length(mediators))
b_paths <- paste0("b", 1:length(mediators))
indirect_effects <- paste0("ind", 1:length(mediators))

model_parts <- character()

# a paths (IV to each mediator)
for (i in 1:length(mediators)) {
  model_parts <- c(model_parts, paste0(mediators[i], " ~ ", a_paths[i], "*", iv))
}

# b paths and direct effect
b_terms <- paste0(b_paths, "*", mediators, collapse = " + ")
model_parts <- c(model_parts, paste0(dv, " ~ c*", iv, " + ", b_terms))

# Define indirect effects
for (i in 1:length(mediators)) {
  model_parts <- c(model_parts, paste0(indirect_effects[i], " := ", a_paths[i], "*", b_paths[i]))
}

# Total indirect effect
total_indirect <- paste0("total_indirect := ", paste(indirect_effects, collapse = " + "))
model_parts <- c(model_parts, total_indirect)

# Total effect
model_parts <- c(model_parts, paste0("total := c + (", paste(indirect_effects, collapse = " + "), ")"))

model_syntax <- paste(model_parts, collapse = "\n")

# Fit model
fit <- sem(model_syntax, data = data_df, se = "bootstrap", bootstrap = 5000)

# Extract results
params <- parameterEstimates(fit, boot.ci.type = "perc", standardized = TRUE)
fit_measures <- fitMeasures(fit, c("chisq", "df", "pvalue", "cfi", "tli", "rmsea", "srmr"))
r_squared <- inspect(fit, "r2")

# Generate path diagram
png("parallel_mediation_diagram.png", width = 1400, height = 900, res = 150)
semPaths(fit, what = "est", layout = "tree2", edge.label.cex = 0.9,
         style = "lisrel", curve = 1.2, nCharNodes = 0,
         sizeMan = 8, edge.color = "black",
         label.cex = 1, residuals = TRUE, intercepts = FALSE)
title("Parallel Mediation Model", line = 3, cex.main = 1.3)
dev.off()

# Extract specific effects
indirect_list <- lapply(indirect_effects, function(ie) {
  params[params$label == ie, ]
})
names(indirect_list) <- mediators

results <- list(
  model_type = "parallel_mediation",
  indirect_effects = indirect_list,
  total_indirect = params[params$label == "total_indirect", ],
  direct_effect = params[params$label == "c", ],
  total_effect = params[params$label == "total", ],
  all_parameters = params,
  fit_measures = as.list(fit_measures),
  r_squared = r_squared,
  model_syntax = model_syntax
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["lavaan", "jsonlite", "semPlot"]',
  'Parallel mediation with multiple mediators in parallel'
);

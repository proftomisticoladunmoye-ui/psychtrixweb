/*
  # Add IRT Analysis Templates

  1. Templates Added
    - 2PL IRT Model (mirt package)
    - 3PL IRT Model (mirt package)
    - Graded Response Model (mirt package)
    - DIF Analysis (mirt package)

  2. Features
    - Item parameter estimation
    - Person ability estimation
    - Item and test information functions
    - DIF analysis support
    - Model fit indices
    - ICC and TIF plots
*/

-- Insert IRT analysis templates
INSERT INTO r_analysis_templates (template_name, job_type, r_script_template, required_packages, description) VALUES
(
  'irt_2pl_model',
  'irt',
  '# 2PL IRT Model using mirt
library(mirt)
library(jsonlite)
library(latticeExtra)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_matrix <- as.data.frame(input$data)
colnames(data_matrix) <- input$variables

# Ensure binary responses
data_matrix[] <- lapply(data_matrix, function(x) as.integer(as.numeric(x)))

# Fit 2PL model
model <- mirt(data_matrix, model = 1, itemtype = "2PL", verbose = FALSE)

# Extract item parameters
item_params <- coef(model, IRTpars = TRUE, simplify = TRUE)$items

# Extract person abilities (factor scores)
person_scores <- fscores(model, method = "EAP", full.scores = TRUE)

# Model fit indices
fit_indices <- M2(model, type = "C2")

# Item fit statistics
item_fit <- itemfit(model, empirical.plot = FALSE)

# Test information
theta_range <- seq(-4, 4, length.out = 100)
test_info <- testinfo(model, Theta = theta_range)

# Item information curves
item_info_list <- lapply(1:ncol(data_matrix), function(i) {
  iteminfo(extract.item(model, i), Theta = theta_range)
})

# Generate ICC plots
png("icc_plot.png", width = 1200, height = 800, res = 150)
plot(model, type = "trace", facet_items = TRUE,
     main = "Item Characteristic Curves (2PL Model)")
dev.off()

# Generate TIF plot
png("tif_plot.png", width = 1000, height = 600, res = 150)
plot(theta_range, test_info, type = "l", lwd = 2, col = "blue",
     xlab = "Ability (θ)", ylab = "Test Information",
     main = "Test Information Function")
grid()
dev.off()

# Generate item info plot
png("iif_plot.png", width = 1200, height = 800, res = 150)
plot(theta_range, item_info_list[[1]], type = "l", lwd = 2,
     xlab = "Ability (θ)", ylab = "Item Information",
     main = "Item Information Functions",
     ylim = c(0, max(unlist(item_info_list))))
for (i in 2:length(item_info_list)) {
  lines(theta_range, item_info_list[[i]], lwd = 2, col = i)
}
legend("topright", legend = colnames(data_matrix), col = 1:ncol(data_matrix), lwd = 2)
dev.off()

# Prepare results
results <- list(
  model_type = "2PL",
  item_parameters = data.frame(
    item = colnames(data_matrix),
    discrimination = item_params[, "a"],
    difficulty = item_params[, "b"],
    infit = item_fit$infit,
    outfit = item_fit$outfit,
    infit_pvalue = item_fit$infit.pvalue,
    outfit_pvalue = item_fit$outfit.pvalue
  ),
  person_abilities = data.frame(
    person = paste0("Person_", sprintf("%03d", 1:nrow(data_matrix))),
    ability = person_scores[, 1],
    se = person_scores[, 2]
  ),
  model_fit = list(
    M2 = fit_indices$M2,
    df = fit_indices$df,
    pvalue = fit_indices$p.M2,
    RMSEA = fit_indices$RMSEA,
    RMSEA_lower = fit_indices$RMSEA_5,
    RMSEA_upper = fit_indices$RMSEA_95,
    CFI = fit_indices$CFI,
    TLI = fit_indices$TLI,
    SRMSR = fit_indices$SRMSR,
    logLikelihood = logLik(model),
    AIC = AIC(model),
    BIC = BIC(model)
  ),
  test_information = data.frame(
    theta = theta_range,
    information = test_info,
    se = 1 / sqrt(test_info)
  ),
  reliability = marginal_rxx(model)
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["mirt", "jsonlite", "latticeExtra"]',
  '2PL IRT model estimation with item parameters, person abilities, and fit indices'
),
(
  'irt_3pl_model',
  'irt',
  '# 3PL IRT Model using mirt
library(mirt)
library(jsonlite)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_matrix <- as.data.frame(input$data)
colnames(data_matrix) <- input$variables

# Ensure binary responses
data_matrix[] <- lapply(data_matrix, function(x) as.integer(as.numeric(x)))

# Fit 3PL model
model <- mirt(data_matrix, model = 1, itemtype = "3PL", verbose = FALSE)

# Extract item parameters
item_params <- coef(model, IRTpars = TRUE, simplify = TRUE)$items

# Extract person abilities
person_scores <- fscores(model, method = "EAP", full.scores = TRUE)

# Model fit
fit_indices <- M2(model, type = "C2")

# Item fit
item_fit <- itemfit(model, empirical.plot = FALSE)

# Test information
theta_range <- seq(-4, 4, length.out = 100)
test_info <- testinfo(model, Theta = theta_range)

# Generate plots
png("icc_plot_3pl.png", width = 1200, height = 800, res = 150)
plot(model, type = "trace", facet_items = TRUE,
     main = "Item Characteristic Curves (3PL Model)")
dev.off()

png("tif_plot_3pl.png", width = 1000, height = 600, res = 150)
plot(theta_range, test_info, type = "l", lwd = 2, col = "darkgreen",
     xlab = "Ability (θ)", ylab = "Test Information",
     main = "Test Information Function (3PL)")
grid()
dev.off()

# Prepare results
results <- list(
  model_type = "3PL",
  item_parameters = data.frame(
    item = colnames(data_matrix),
    discrimination = item_params[, "a"],
    difficulty = item_params[, "b"],
    guessing = item_params[, "g"],
    infit = item_fit$infit,
    outfit = item_fit$outfit
  ),
  person_abilities = data.frame(
    person = paste0("Person_", sprintf("%03d", 1:nrow(data_matrix))),
    ability = person_scores[, 1],
    se = person_scores[, 2]
  ),
  model_fit = list(
    M2 = fit_indices$M2,
    df = fit_indices$df,
    pvalue = fit_indices$p.M2,
    RMSEA = fit_indices$RMSEA,
    CFI = fit_indices$CFI,
    TLI = fit_indices$TLI,
    logLikelihood = logLik(model),
    AIC = AIC(model),
    BIC = BIC(model)
  ),
  test_information = data.frame(
    theta = theta_range,
    information = test_info,
    se = 1 / sqrt(test_info)
  ),
  reliability = marginal_rxx(model)
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["mirt", "jsonlite"]',
  '3PL IRT model with guessing parameter estimation'
),
(
  'irt_graded_response',
  'irt',
  '# Graded Response Model using mirt
library(mirt)
library(jsonlite)

# Load data
input <- fromJSON(''{{INPUT_DATA}}'')
data_matrix <- as.data.frame(input$data)
colnames(data_matrix) <- input$variables

# Fit GRM
model <- mirt(data_matrix, model = 1, itemtype = "graded", verbose = FALSE)

# Extract parameters
item_params <- coef(model, simplify = TRUE)$items

# Person scores
person_scores <- fscores(model, method = "EAP", full.scores = TRUE)

# Model fit
fit_indices <- M2(model)

# Test information
theta_range <- seq(-4, 4, length.out = 100)
test_info <- testinfo(model, Theta = theta_range)

# Generate plots
png("grm_plot.png", width = 1200, height = 800, res = 150)
plot(model, type = "trace", facet_items = TRUE,
     main = "Category Response Curves (Graded Response Model)")
dev.off()

png("grm_tif.png", width = 1000, height = 600, res = 150)
plot(theta_range, test_info, type = "l", lwd = 2, col = "purple",
     xlab = "Ability (θ)", ylab = "Test Information",
     main = "Test Information Function (GRM)")
grid()
dev.off()

# Prepare results
results <- list(
  model_type = "GRM",
  item_parameters = as.data.frame(item_params),
  person_abilities = data.frame(
    person = paste0("Person_", sprintf("%03d", 1:nrow(data_matrix))),
    ability = person_scores[, 1],
    se = person_scores[, 2]
  ),
  model_fit = list(
    M2 = fit_indices$M2,
    df = fit_indices$df,
    pvalue = fit_indices$p.M2,
    RMSEA = fit_indices$RMSEA,
    CFI = fit_indices$CFI,
    TLI = fit_indices$TLI,
    AIC = AIC(model),
    BIC = BIC(model)
  ),
  test_information = data.frame(
    theta = theta_range,
    information = test_info
  ),
  reliability = marginal_rxx(model)
)

cat(toJSON(results, auto_unbox = TRUE, digits = 4))
',
  '["mirt", "jsonlite"]',
  'Graded Response Model for polytomous items'
);
/*
  # PLS-SEM Module Database Schema

  1. New Tables
    - `plssem_models`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text)
      - `description` (text)
      - `dataset_id` (uuid, foreign key to datasets)
      - `model_specification` (jsonb) - constructs, indicators, paths
      - `estimation_settings` (jsonb) - weighting scheme, bootstrap settings
      - `results` (jsonb) - all outputs
      - `status` (text) - draft, running, completed, error
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `plssem_analyses`
      - `id` (uuid, primary key)
      - `model_id` (uuid, foreign key to plssem_models)
      - `analysis_type` (text) - measurement, structural, mga, mediation, etc.
      - `configuration` (jsonb)
      - `results` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can only access their own PLS-SEM models
*/

-- Create PLS-SEM models table
CREATE TABLE IF NOT EXISTS plssem_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text,
  dataset_id uuid REFERENCES datasets(id) ON DELETE SET NULL,
  model_specification jsonb DEFAULT '{}'::jsonb,
  estimation_settings jsonb DEFAULT '{
    "weightingScheme": "path",
    "maxIterations": 300,
    "convergenceCriterion": 0.00001,
    "bootstrapSamples": 5000,
    "blindfoldingOmissionDistance": 7,
    "confidenceLevel": 0.95
  }'::jsonb,
  results jsonb,
  status text DEFAULT 'draft',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create PLS-SEM analyses table
CREATE TABLE IF NOT EXISTS plssem_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_id uuid REFERENCES plssem_models(id) ON DELETE CASCADE NOT NULL,
  analysis_type text NOT NULL,
  configuration jsonb DEFAULT '{}'::jsonb,
  results jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE plssem_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE plssem_analyses ENABLE ROW LEVEL SECURITY;

-- RLS Policies for plssem_models
CREATE POLICY "Users can view own PLS-SEM models"
  ON plssem_models FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own PLS-SEM models"
  ON plssem_models FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own PLS-SEM models"
  ON plssem_models FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own PLS-SEM models"
  ON plssem_models FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for plssem_analyses
CREATE POLICY "Users can view own PLS-SEM analyses"
  ON plssem_analyses FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM plssem_models
      WHERE plssem_models.id = plssem_analyses.model_id
      AND plssem_models.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own PLS-SEM analyses"
  ON plssem_analyses FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM plssem_models
      WHERE plssem_models.id = plssem_analyses.model_id
      AND plssem_models.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own PLS-SEM analyses"
  ON plssem_analyses FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM plssem_models
      WHERE plssem_models.id = plssem_analyses.model_id
      AND plssem_models.user_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_plssem_models_user_id ON plssem_models(user_id);
CREATE INDEX IF NOT EXISTS idx_plssem_models_dataset_id ON plssem_models(dataset_id);
CREATE INDEX IF NOT EXISTS idx_plssem_models_status ON plssem_models(status);
CREATE INDEX IF NOT EXISTS idx_plssem_analyses_model_id ON plssem_analyses(model_id);
CREATE INDEX IF NOT EXISTS idx_plssem_analyses_type ON plssem_analyses(analysis_type);

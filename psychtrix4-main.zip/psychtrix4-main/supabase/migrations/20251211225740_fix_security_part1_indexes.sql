/*
  # Fix Security Issues - Part 1: Add Missing Indexes

  This migration adds indexes on foreign key columns to improve query performance.

  ## Indexes Added
  - dif_analyses.group2_id
  - email_queue.user_id
  - forum_posts.user_id
  - forum_replies.user_id
  - messages.parent_message_id
*/

CREATE INDEX IF NOT EXISTS idx_dif_analyses_group2_id 
  ON dif_analyses(group2_id);

CREATE INDEX IF NOT EXISTS idx_email_queue_user_id 
  ON email_queue(user_id);

CREATE INDEX IF NOT EXISTS idx_forum_posts_user_id 
  ON forum_posts(user_id);

CREATE INDEX IF NOT EXISTS idx_forum_replies_user_id 
  ON forum_replies(user_id);

CREATE INDEX IF NOT EXISTS idx_messages_parent_message_id 
  ON messages(parent_message_id);

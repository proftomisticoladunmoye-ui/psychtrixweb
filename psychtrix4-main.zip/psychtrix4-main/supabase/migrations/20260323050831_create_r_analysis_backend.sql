/*
  # Create R Analysis Backend System

  1. New Tables
    - `r_analysis_jobs`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `job_type` (text) - network, efa, cfa, sem, irt, reliability, etc
      - `status` (text) - queued, processing, completed, failed
      - `priority` (integer) - Job priority (1-10)
      - `input_data` (jsonb) - Dataset and parameters
      - `r_script` (text) - Generated R script
      - `output_data` (jsonb) - Results and statistics
      - `output_images` (jsonb) - Generated visualization URLs
      - `error_message` (text) - Error details if failed
      - `execution_time` (numeric) - Seconds to complete
      - `created_at` (timestamptz)
      - `started_at` (timestamptz)
      - `completed_at` (timestamptz)

    - `r_analysis_cache`
      - `id` (uuid, primary key)
      - `cache_key` (text, unique) - Hash of input data
      - `job_type` (text)
      - `output_data` (jsonb)
      - `output_images` (jsonb)
      - `hit_count` (integer) - Number of cache hits
      - `created_at` (timestamptz)
      - `last_accessed` (timestamptz)

    - `r_analysis_logs`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to r_analysis_jobs)
      - `user_id` (uuid, foreign key to auth.users)
      - `log_level` (text) - info, warning, error
      - `message` (text)
      - `r_output` (text) - R console output
      - `created_at` (timestamptz)

    - `r_analysis_templates`
      - `id` (uuid, primary key)
      - `template_name` (text, unique)
      - `job_type` (text)
      - `r_script_template` (text) - Template with placeholders
      - `required_packages` (jsonb) - Required R packages
      - `parameters_schema` (jsonb) - Expected parameters
      - `description` (text)
      - `version` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `r_analysis_reports`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `job_id` (uuid, foreign key to r_analysis_jobs)
      - `report_type` (text) - pdf, html, rmarkdown
      - `report_content` (text) - Generated report
      - `report_url` (text) - Storage URL
      - `metadata` (jsonb) - Analysis metadata
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can only access their own jobs and reports
    - Templates are globally readable but admin-writable

  3. Indexes
    - Performance indexes on job status and user_id
    - Index on cache_key for fast lookups
*/

-- Create r_analysis_jobs table
CREATE TABLE IF NOT EXISTS r_analysis_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  job_type text NOT NULL,
  status text DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'completed', 'failed', 'cancelled')),
  priority integer DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
  input_data jsonb NOT NULL DEFAULT '{}',
  r_script text,
  output_data jsonb DEFAULT '{}',
  output_images jsonb DEFAULT '[]',
  error_message text,
  execution_time numeric,
  created_at timestamptz DEFAULT now(),
  started_at timestamptz,
  completed_at timestamptz
);

-- Create r_analysis_cache table
CREATE TABLE IF NOT EXISTS r_analysis_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key text UNIQUE NOT NULL,
  job_type text NOT NULL,
  output_data jsonb NOT NULL DEFAULT '{}',
  output_images jsonb DEFAULT '[]',
  hit_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  last_accessed timestamptz DEFAULT now()
);

-- Create r_analysis_logs table
CREATE TABLE IF NOT EXISTS r_analysis_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES r_analysis_jobs(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  log_level text DEFAULT 'info' CHECK (log_level IN ('info', 'warning', 'error', 'debug')),
  message text NOT NULL,
  r_output text,
  created_at timestamptz DEFAULT now()
);

-- Create r_analysis_templates table
CREATE TABLE IF NOT EXISTS r_analysis_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_name text UNIQUE NOT NULL,
  job_type text NOT NULL,
  r_script_template text NOT NULL,
  required_packages jsonb DEFAULT '[]',
  parameters_schema jsonb DEFAULT '{}',
  description text,
  version text DEFAULT '1.0.0',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create r_analysis_reports table
CREATE TABLE IF NOT EXISTS r_analysis_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  job_id uuid REFERENCES r_analysis_jobs(id) ON DELETE CASCADE NOT NULL,
  report_type text NOT NULL CHECK (report_type IN ('pdf', 'html', 'rmarkdown', 'docx')),
  report_content text,
  report_url text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_r_jobs_user_status ON r_analysis_jobs(user_id, status);
CREATE INDEX IF NOT EXISTS idx_r_jobs_status_priority ON r_analysis_jobs(status, priority DESC);
CREATE INDEX IF NOT EXISTS idx_r_jobs_created ON r_analysis_jobs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_r_cache_key ON r_analysis_cache(cache_key);
CREATE INDEX IF NOT EXISTS idx_r_cache_type ON r_analysis_cache(job_type);
CREATE INDEX IF NOT EXISTS idx_r_logs_job ON r_analysis_logs(job_id, created_at);
CREATE INDEX IF NOT EXISTS idx_r_templates_type ON r_analysis_templates(job_type);
CREATE INDEX IF NOT EXISTS idx_r_reports_user ON r_analysis_reports(user_id, created_at DESC);

-- Enable Row Level Security
ALTER TABLE r_analysis_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE r_analysis_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE r_analysis_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE r_analysis_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE r_analysis_reports ENABLE ROW LEVEL SECURITY;

-- RLS Policies for r_analysis_jobs
CREATE POLICY "Users can view own analysis jobs"
  ON r_analysis_jobs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own analysis jobs"
  ON r_analysis_jobs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own analysis jobs"
  ON r_analysis_jobs FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own analysis jobs"
  ON r_analysis_jobs FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for r_analysis_cache (globally readable for cache hits)
CREATE POLICY "Anyone can read cache"
  ON r_analysis_cache FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage cache"
  ON r_analysis_cache FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for r_analysis_logs
CREATE POLICY "Users can view logs for their jobs"
  ON r_analysis_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create logs"
  ON r_analysis_logs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for r_analysis_templates (globally readable)
CREATE POLICY "Anyone can read templates"
  ON r_analysis_templates FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for r_analysis_reports
CREATE POLICY "Users can view own reports"
  ON r_analysis_reports FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own reports"
  ON r_analysis_reports FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reports"
  ON r_analysis_reports FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reports"
  ON r_analysis_reports FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to update job status
CREATE OR REPLACE FUNCTION update_job_status()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'processing' AND OLD.status = 'queued' THEN
    NEW.started_at = now();
  END IF;
  
  IF NEW.status IN ('completed', 'failed', 'cancelled') AND OLD.status = 'processing' THEN
    NEW.completed_at = now();
    IF NEW.started_at IS NOT NULL THEN
      NEW.execution_time = EXTRACT(EPOCH FROM (now() - NEW.started_at));
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_r_job_status
  BEFORE UPDATE ON r_analysis_jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_job_status();

-- Function to clean old cache entries (keep only last 1000 entries)
CREATE OR REPLACE FUNCTION clean_old_cache()
RETURNS void AS $$
BEGIN
  DELETE FROM r_analysis_cache
  WHERE id NOT IN (
    SELECT id FROM r_analysis_cache
    ORDER BY last_accessed DESC
    LIMIT 1000
  );
END;
$$ LANGUAGE plpgsql;

-- Function to get next queued job
CREATE OR REPLACE FUNCTION get_next_queued_job()
RETURNS uuid AS $$
DECLARE
  job_id uuid;
BEGIN
  SELECT id INTO job_id
  FROM r_analysis_jobs
  WHERE status = 'queued'
  ORDER BY priority DESC, created_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED;
  
  IF job_id IS NOT NULL THEN
    UPDATE r_analysis_jobs
    SET status = 'processing', started_at = now()
    WHERE id = job_id;
  END IF;
  
  RETURN job_id;
END;
$$ LANGUAGE plpgsql;

-- Insert default R analysis templates
INSERT INTO r_analysis_templates (template_name, job_type, r_script_template, required_packages, description) VALUES
(
  'network_qgraph',
  'network',
  '# Network Analysis using qgraph and bootnet
library(qgraph)
library(bootnet)
library(psychonetrics)
library(jsonlite)

# Load data
data <- fromJSON(''{{INPUT_DATA}}'')
data_matrix <- as.matrix(data$data)
var_names <- data$variables

# Estimate network using EBICglasso
network <- estimateNetwork(data_matrix, default = "EBICglasso", 
                           corMethod = "cor", gamma = {{GAMMA}})

# Calculate centrality
cent <- centrality(network)

# Bootstrap stability
boot_results <- bootnet(network, nBoots = {{N_BOOTS}}, 
                        statistics = c("edge", "strength", "closeness", "betweenness"))

# Community detection
communities <- spinglass.community(network$graph)

# Generate visualization
png("network_plot.png", width = 1200, height = 1200, res = 150)
qgraph(network$graph, layout = "spring", labels = var_names,
       groups = communities$membership, legend = TRUE)
dev.off()

# Export results
results <- list(
  edge_weights = network$graph,
  centrality = cent,
  stability = summary(boot_results),
  communities = communities$membership,
  modularity = modularity(communities)
)

cat(toJSON(results, auto_unbox = TRUE))
',
  '["qgraph", "bootnet", "psychonetrics", "jsonlite", "igraph"]',
  'Network analysis with qgraph and bootstrap stability'
),
(
  'reliability_analysis',
  'reliability',
  '# Reliability Analysis
library(psych)
library(jsonlite)

# Load data
data <- fromJSON(''{{INPUT_DATA}}'')
data_matrix <- as.matrix(data$data)

# Cronbach''s Alpha
alpha_result <- alpha(data_matrix)

# McDonald''s Omega
omega_result <- omega(data_matrix, nfactors = {{N_FACTORS}})

# Item-total correlations
item_total <- cor(data_matrix, rowSums(data_matrix))

# Generate reliability plot
png("reliability_plot.png", width = 800, height = 600, res = 150)
plot(alpha_result)
dev.off()

results <- list(
  cronbach_alpha = alpha_result$total$raw_alpha,
  standardized_alpha = alpha_result$total$std.alpha,
  omega_total = omega_result$omega.tot,
  omega_hierarchical = omega_result$omega_h,
  item_statistics = alpha_result$item.stats
)

cat(toJSON(results, auto_unbox = TRUE))
',
  '["psych", "jsonlite"]',
  'Reliability analysis with Cronbach alpha and McDonald omega'
),
(
  'cfa_lavaan',
  'cfa',
  '# Confirmatory Factor Analysis using lavaan
library(lavaan)
library(semPlot)
library(jsonlite)

# Load data
data <- fromJSON(''{{INPUT_DATA}}'')
data_df <- as.data.frame(data$data)
colnames(data_df) <- data$variables

# CFA model
model <- ''{{MODEL_SYNTAX}}''

# Fit model
fit <- cfa(model, data = data_df, std.lv = TRUE)

# Get fit indices
fit_measures <- fitMeasures(fit, c("chisq", "df", "pvalue", "cfi", "tli", 
                                     "rmsea", "rmsea.ci.lower", "rmsea.ci.upper", 
                                     "srmr", "aic", "bic"))

# Parameter estimates
params <- parameterEstimates(fit, standardized = TRUE)

# Generate path diagram
png("cfa_diagram.png", width = 1000, height = 800, res = 150)
semPaths(fit, what = "std", layout = "tree", 
         edge.label.cex = 0.8, curvePivot = TRUE)
dev.off()

results <- list(
  fit_indices = as.list(fit_measures),
  parameters = params,
  reliability = reliability(fit),
  modification_indices = modindices(fit, sort = TRUE, maximum.number = 10)
)

cat(toJSON(results, auto_unbox = TRUE))
',
  '["lavaan", "semPlot", "jsonlite"]',
  'Confirmatory Factor Analysis with lavaan'
);

/*
  # Forum Email Notification System

  1. New Tables
    - `user_notification_preferences` - Store user email notification settings
    - `email_queue` - Queue for pending email notifications

  2. Functions
    - Triggers to create notifications for:
      - New replies to user's posts
      - New posts in watched categories
      - Solution marked on user's reply
      - Admin replies to posts

  3. Security
    - Enable RLS on all new tables
    - Users can only manage their own preferences
*/

-- Create user notification preferences table
CREATE TABLE IF NOT EXISTS user_notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  email_on_reply boolean DEFAULT true,
  email_on_solution boolean DEFAULT true,
  email_on_admin_reply boolean DEFAULT true,
  email_daily_digest boolean DEFAULT false,
  email_weekly_digest boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_notification_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own preferences"
  ON user_notification_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own preferences"
  ON user_notification_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own preferences"
  ON user_notification_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create email queue table
CREATE TABLE IF NOT EXISTS email_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  recipient_email text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  notification_type text NOT NULL,
  related_post_id uuid,
  related_reply_id uuid,
  sent boolean DEFAULT false,
  sent_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE email_queue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only system can manage email queue"
  ON email_queue FOR ALL
  TO authenticated
  USING (false)
  WITH CHECK (false);

-- Function to get user notification preferences (creates default if not exists)
CREATE OR REPLACE FUNCTION get_user_notification_prefs(user_uuid uuid)
RETURNS user_notification_preferences AS $$
DECLARE
  prefs user_notification_preferences;
BEGIN
  SELECT * INTO prefs
  FROM user_notification_preferences
  WHERE user_id = user_uuid;
  
  IF NOT FOUND THEN
    INSERT INTO user_notification_preferences (user_id)
    VALUES (user_uuid)
    RETURNING * INTO prefs;
  END IF;
  
  RETURN prefs;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to queue email notification
CREATE OR REPLACE FUNCTION queue_email_notification(
  p_user_id uuid,
  p_recipient_email text,
  p_subject text,
  p_body text,
  p_notification_type text,
  p_related_post_id uuid DEFAULT NULL,
  p_related_reply_id uuid DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  INSERT INTO email_queue (
    user_id,
    recipient_email,
    subject,
    body,
    notification_type,
    related_post_id,
    related_reply_id
  ) VALUES (
    p_user_id,
    p_recipient_email,
    p_subject,
    p_body,
    p_notification_type,
    p_related_post_id,
    p_related_reply_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function: Notify when someone replies to your post
CREATE OR REPLACE FUNCTION notify_post_author_on_reply()
RETURNS trigger AS $$
DECLARE
  post_author_id uuid;
  post_author_email text;
  post_title text;
  reply_author_email text;
  prefs user_notification_preferences;
BEGIN
  -- Get post details
  SELECT user_id, user_email, title
  INTO post_author_id, post_author_email, post_title
  FROM forum_posts
  WHERE id = NEW.post_id;
  
  -- Don't notify if replying to own post
  IF post_author_id = NEW.user_id THEN
    RETURN NEW;
  END IF;
  
  -- Get reply author email
  reply_author_email := NEW.user_email;
  
  -- Check user preferences
  prefs := get_user_notification_prefs(post_author_id);
  
  -- Create in-app notification
  INSERT INTO notifications (
    user_id,
    type,
    title,
    message,
    link,
    related_id
  ) VALUES (
    post_author_id,
    'forum_reply',
    'New Reply to Your Post',
    reply_author_email || ' replied to your post: "' || post_title || '"',
    '/forum?post=' || NEW.post_id,
    NEW.id
  );
  
  -- Queue email if preferences allow
  IF prefs.email_on_reply THEN
    PERFORM queue_email_notification(
      post_author_id,
      post_author_email,
      'New Reply: ' || post_title,
      'Hi,' || E'\n\n' ||
      reply_author_email || ' replied to your post "' || post_title || '"' || E'\n\n' ||
      'Reply: ' || NEW.body || E'\n\n' ||
      'View the discussion: ' || current_setting('app.settings.base_url', true) || '/forum?post=' || NEW.post_id,
      'forum_reply',
      NEW.post_id,
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS notify_on_forum_reply ON forum_replies;
CREATE TRIGGER notify_on_forum_reply
  AFTER INSERT ON forum_replies
  FOR EACH ROW
  EXECUTE FUNCTION notify_post_author_on_reply();

-- Trigger function: Notify when solution is marked
CREATE OR REPLACE FUNCTION notify_on_solution_marked()
RETURNS trigger AS $$
DECLARE
  reply_author_id uuid;
  reply_author_email text;
  post_title text;
  prefs user_notification_preferences;
BEGIN
  -- Only trigger if is_solution changed from false to true
  IF NEW.is_solution = true AND (OLD.is_solution IS NULL OR OLD.is_solution = false) THEN
    -- Get reply author details
    SELECT user_id, user_email INTO reply_author_id, reply_author_email
    FROM forum_replies
    WHERE id = NEW.id;
    
    -- Get post title
    SELECT title INTO post_title
    FROM forum_posts
    WHERE id = NEW.post_id;
    
    -- Check user preferences
    prefs := get_user_notification_prefs(reply_author_id);
    
    -- Create in-app notification
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      link,
      related_id
    ) VALUES (
      reply_author_id,
      'forum_reply',
      'Your Reply Marked as Solution',
      'Your reply to "' || post_title || '" was marked as the solution!',
      '/forum?post=' || NEW.post_id,
      NEW.id
    );
    
    -- Queue email if preferences allow
    IF prefs.email_on_solution THEN
      PERFORM queue_email_notification(
        reply_author_id,
        reply_author_email,
        '🎉 Solution Accepted: ' || post_title,
        'Hi,' || E'\n\n' ||
        'Great news! Your reply to "' || post_title || '" was marked as the solution.' || E'\n\n' ||
        'View the discussion: ' || current_setting('app.settings.base_url', true) || '/forum?post=' || NEW.post_id,
        'solution_marked',
        NEW.post_id,
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS notify_on_solution ON forum_replies;
CREATE TRIGGER notify_on_solution
  AFTER UPDATE ON forum_replies
  FOR EACH ROW
  WHEN (NEW.is_solution = true)
  EXECUTE FUNCTION notify_on_solution_marked();

-- Trigger function: Notify all users when admin replies
CREATE OR REPLACE FUNCTION notify_on_admin_reply()
RETURNS trigger AS $$
DECLARE
  post_author_id uuid;
  post_author_email text;
  post_title text;
  admin_email text;
  prefs user_notification_preferences;
  reply_user record;
BEGIN
  -- Only for admin replies
  IF NEW.is_admin_reply = true THEN
    -- Get post details
    SELECT user_id, user_email, title
    INTO post_author_id, post_author_email, post_title
    FROM forum_posts
    WHERE id = NEW.post_id;
    
    admin_email := NEW.user_email;
    
    -- Notify post author if not the admin
    IF post_author_id != NEW.user_id THEN
      prefs := get_user_notification_prefs(post_author_id);
      
      INSERT INTO notifications (
        user_id,
        type,
        title,
        message,
        link,
        related_id
      ) VALUES (
        post_author_id,
        'forum_reply',
        'Admin Replied to Your Post',
        'An admin replied to your post: "' || post_title || '"',
        '/forum?post=' || NEW.post_id,
        NEW.id
      );
      
      IF prefs.email_on_admin_reply THEN
        PERFORM queue_email_notification(
          post_author_id,
          post_author_email,
          '👤 Admin Reply: ' || post_title,
          'Hi,' || E'\n\n' ||
          'An admin replied to your post "' || post_title || '"' || E'\n\n' ||
          'Admin Reply: ' || NEW.body || E'\n\n' ||
          'View the discussion: ' || current_setting('app.settings.base_url', true) || '/forum?post=' || NEW.post_id,
          'admin_reply',
          NEW.post_id,
          NEW.id
        );
      END IF;
    END IF;
    
    -- Notify all other users who replied (excluding admin and post author)
    FOR reply_user IN
      SELECT DISTINCT r.user_id, r.user_email
      FROM forum_replies r
      WHERE r.post_id = NEW.post_id
        AND r.user_id != NEW.user_id
        AND r.user_id != post_author_id
        AND r.id != NEW.id
    LOOP
      prefs := get_user_notification_prefs(reply_user.user_id);
      
      INSERT INTO notifications (
        user_id,
        type,
        title,
        message,
        link,
        related_id
      ) VALUES (
        reply_user.user_id,
        'forum_reply',
        'Admin Reply in Discussion',
        'An admin replied to a discussion you participated in: "' || post_title || '"',
        '/forum?post=' || NEW.post_id,
        NEW.id
      );
      
      IF prefs.email_on_admin_reply THEN
        PERFORM queue_email_notification(
          reply_user.user_id,
          reply_user.user_email,
          '👤 Admin Reply: ' || post_title,
          'Hi,' || E'\n\n' ||
          'An admin replied to a discussion you participated in: "' || post_title || '"' || E'\n\n' ||
          'View the discussion: ' || current_setting('app.settings.base_url', true) || '/forum?post=' || NEW.post_id,
          'admin_reply',
          NEW.post_id,
          NEW.id
        );
      END IF;
    END LOOP;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS notify_on_admin_reply_trigger ON forum_replies;
CREATE TRIGGER notify_on_admin_reply_trigger
  AFTER INSERT ON forum_replies
  FOR EACH ROW
  WHEN (NEW.is_admin_reply = true)
  EXECUTE FUNCTION notify_on_admin_reply();

-- Insert default preferences for existing users
INSERT INTO user_notification_preferences (user_id)
SELECT id FROM auth.users
WHERE id NOT IN (SELECT user_id FROM user_notification_preferences)
ON CONFLICT (user_id) DO NOTHING;
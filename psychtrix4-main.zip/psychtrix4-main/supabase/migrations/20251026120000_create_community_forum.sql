/*
  # Community Forum System

  1. New Tables
    - `forum_categories`
      - `id` (uuid, primary key)
      - `name` (text) - Category name (e.g., "Statistical Tools", "Study Design")
      - `description` (text) - Category description
      - `icon` (text) - Icon identifier
      - `sort_order` (integer) - Display order
      - `created_at` (timestamptz)

    - `forum_posts`
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key)
      - `user_id` (uuid, foreign key to auth.users)
      - `title` (text) - Post title
      - `content` (text) - Post content
      - `is_pinned` (boolean) - Pinned by admin
      - `is_locked` (boolean) - Locked for comments
      - `views_count` (integer) - View counter
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `forum_comments`
      - `id` (uuid, primary key)
      - `post_id` (uuid, foreign key)
      - `user_id` (uuid, foreign key to auth.users)
      - `content` (text) - Comment content
      - `is_solution` (boolean) - Marked as solution by post author
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `forum_votes`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `post_id` (uuid, foreign key, nullable)
      - `comment_id` (uuid, foreign key, nullable)
      - `vote_type` (text) - 'upvote' or 'downvote'
      - `created_at` (timestamptz)

    - `forum_admins`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users, unique)
      - `email` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public can read posts and comments
    - Authenticated users can create posts and comments
    - Users can edit/delete their own content
    - Admins have full permissions
*/

-- Create forum_categories table
CREATE TABLE IF NOT EXISTS forum_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  icon text DEFAULT 'message-circle',
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE forum_categories ENABLE ROW LEVEL SECURITY;

-- Everyone can view categories
CREATE POLICY "Anyone can view forum categories"
  ON forum_categories FOR SELECT
  TO public
  USING (true);

-- Only admins can manage categories
CREATE POLICY "Admins can manage forum categories"
  ON forum_categories FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  );

-- Create forum_posts table
CREATE TABLE IF NOT EXISTS forum_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES forum_categories(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  is_pinned boolean DEFAULT false,
  is_locked boolean DEFAULT false,
  views_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;

-- Anyone can view posts
CREATE POLICY "Anyone can view forum posts"
  ON forum_posts FOR SELECT
  TO public
  USING (true);

-- Authenticated users can create posts
CREATE POLICY "Authenticated users can create posts"
  ON forum_posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own posts
CREATE POLICY "Users can update own posts"
  ON forum_posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Users can delete their own posts, admins can delete any
CREATE POLICY "Users can delete own posts"
  ON forum_posts FOR DELETE
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  );

-- Admins can pin/lock posts
CREATE POLICY "Admins can manage all posts"
  ON forum_posts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  );

-- Create forum_comments table
CREATE TABLE IF NOT EXISTS forum_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES forum_posts(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  is_solution boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE forum_comments ENABLE ROW LEVEL SECURITY;

-- Anyone can view comments
CREATE POLICY "Anyone can view forum comments"
  ON forum_comments FOR SELECT
  TO public
  USING (true);

-- Authenticated users can create comments
CREATE POLICY "Authenticated users can create comments"
  ON forum_comments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own comments
CREATE POLICY "Users can update own comments"
  ON forum_comments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Users can delete their own comments, admins can delete any
CREATE POLICY "Users can delete own comments"
  ON forum_comments FOR DELETE
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  );

-- Post authors can mark comments as solution
CREATE POLICY "Post authors can mark solution"
  ON forum_comments FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM forum_posts
      WHERE forum_posts.id = forum_comments.post_id
      AND forum_posts.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM forum_posts
      WHERE forum_posts.id = forum_comments.post_id
      AND forum_posts.user_id = auth.uid()
    )
  );

-- Create forum_votes table
CREATE TABLE IF NOT EXISTS forum_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  post_id uuid REFERENCES forum_posts(id) ON DELETE CASCADE,
  comment_id uuid REFERENCES forum_comments(id) ON DELETE CASCADE,
  vote_type text NOT NULL CHECK (vote_type IN ('upvote', 'downvote')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, post_id, comment_id)
);

ALTER TABLE forum_votes ENABLE ROW LEVEL SECURITY;

-- Anyone can view votes (for counts)
CREATE POLICY "Anyone can view forum votes"
  ON forum_votes FOR SELECT
  TO public
  USING (true);

-- Authenticated users can vote
CREATE POLICY "Authenticated users can vote"
  ON forum_votes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own votes
CREATE POLICY "Users can update own votes"
  ON forum_votes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Users can delete their own votes
CREATE POLICY "Users can delete own votes"
  ON forum_votes FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create forum_admins table
CREATE TABLE IF NOT EXISTS forum_admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  email text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE forum_admins ENABLE ROW LEVEL SECURITY;

-- Anyone can view who admins are
CREATE POLICY "Anyone can view forum admins"
  ON forum_admins FOR SELECT
  TO public
  USING (true);

-- Only existing admins can add new admins
CREATE POLICY "Only admins can manage admins"
  ON forum_admins FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM forum_admins
      WHERE forum_admins.user_id = auth.uid()
    )
  );

-- Insert default categories
INSERT INTO forum_categories (name, description, icon, sort_order) VALUES
  ('Statistical Tools', 'Discuss which statistical methods are best for your research', 'bar-chart', 1),
  ('Study Design', 'Get guidance on research design and methodology', 'clipboard', 2),
  ('Validation & Reliability', 'Questions about test validation and reliability analysis', 'check-circle', 3),
  ('IRT & CTT', 'Item Response Theory and Classical Test Theory discussions', 'trending-up', 4),
  ('SEM & CFA', 'Structural Equation Modeling and Confirmatory Factor Analysis', 'network', 5),
  ('Data Analysis Help', 'General data analysis questions and troubleshooting', 'help-circle', 6),
  ('Feature Requests', 'Suggest new features or improvements', 'lightbulb', 7),
  ('General Discussion', 'General topics related to psychometrics', 'message-circle', 8)
ON CONFLICT DO NOTHING;

-- Create function to increment view count
CREATE OR REPLACE FUNCTION increment_post_views(post_uuid uuid)
RETURNS void AS $$
BEGIN
  UPDATE forum_posts
  SET views_count = views_count + 1
  WHERE id = post_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get post with vote counts and comment count
CREATE OR REPLACE FUNCTION get_forum_post_details(post_uuid uuid)
RETURNS TABLE (
  id uuid,
  category_id uuid,
  user_id uuid,
  title text,
  content text,
  is_pinned boolean,
  is_locked boolean,
  views_count integer,
  created_at timestamptz,
  updated_at timestamptz,
  upvotes_count bigint,
  downvotes_count bigint,
  comments_count bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    p.id,
    p.category_id,
    p.user_id,
    p.title,
    p.content,
    p.is_pinned,
    p.is_locked,
    p.views_count,
    p.created_at,
    p.updated_at,
    COUNT(DISTINCT CASE WHEN v.vote_type = 'upvote' THEN v.id END) as upvotes_count,
    COUNT(DISTINCT CASE WHEN v.vote_type = 'downvote' THEN v.id END) as downvotes_count,
    COUNT(DISTINCT c.id) as comments_count
  FROM forum_posts p
  LEFT JOIN forum_votes v ON v.post_id = p.id
  LEFT JOIN forum_comments c ON c.post_id = p.id
  WHERE p.id = post_uuid
  GROUP BY p.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

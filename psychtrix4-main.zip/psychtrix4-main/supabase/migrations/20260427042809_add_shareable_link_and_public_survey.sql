/*
  # Add Shareable Link and Public Survey Support

  ## Summary
  The sandbox_scale_projects table was missing several columns used by the frontend.
  This migration adds the missing columns and enables anonymous public access for
  data collection without requiring participant accounts.

  ## New Columns on sandbox_scale_projects
  - `shareable_link` (text) — unique token used in the public survey URL
  - `subscales` (jsonb) — array of subscale names
  - `response_scale` (jsonb) — scale configuration (type, min, max, labels)

  ## New Column on scale_responses
  - `completed` (boolean, default false) — whether the respondent finished the survey

  ## Security
  - Anonymous users can SELECT a project using its shareable_link token
  - Anonymous users can INSERT into scale_responses (already allowed)
  - No new write access granted to anonymous users
*/

-- Add missing columns to sandbox_scale_projects
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sandbox_scale_projects' AND column_name = 'shareable_link'
  ) THEN
    ALTER TABLE sandbox_scale_projects ADD COLUMN shareable_link text;
    CREATE UNIQUE INDEX IF NOT EXISTS idx_sandbox_projects_shareable_link ON sandbox_scale_projects(shareable_link) WHERE shareable_link IS NOT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sandbox_scale_projects' AND column_name = 'subscales'
  ) THEN
    ALTER TABLE sandbox_scale_projects ADD COLUMN subscales jsonb NOT NULL DEFAULT '[]'::jsonb;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sandbox_scale_projects' AND column_name = 'response_scale'
  ) THEN
    ALTER TABLE sandbox_scale_projects ADD COLUMN response_scale jsonb NOT NULL DEFAULT '{"type":"likert","min":1,"max":5,"labels":["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]}'::jsonb;
  END IF;
END $$;

-- Also fix the status check constraint to allow 'collecting' and 'analyzed' values used by the app
ALTER TABLE sandbox_scale_projects DROP CONSTRAINT IF EXISTS sandbox_scale_projects_status_check;
ALTER TABLE sandbox_scale_projects ADD CONSTRAINT sandbox_scale_projects_status_check
  CHECK (status IN ('draft', 'collecting', 'analyzed', 'testing', 'validated'));

-- Also update reliability column to be jsonb (the app stores {alpha, omega})
DO $$
BEGIN
  IF (SELECT data_type FROM information_schema.columns WHERE table_name = 'sandbox_scale_projects' AND column_name = 'reliability') = 'numeric' THEN
    ALTER TABLE sandbox_scale_projects ALTER COLUMN reliability TYPE jsonb USING
      CASE WHEN reliability IS NULL THEN NULL ELSE jsonb_build_object('alpha', reliability) END;
  END IF;
END $$;

-- Add `completed` column to scale_responses
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scale_responses' AND column_name = 'completed'
  ) THEN
    ALTER TABLE scale_responses ADD COLUMN completed boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- Allow anonymous users to read a project by its shareable_link
-- (needed so the public survey page can display the survey)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'sandbox_scale_projects'
      AND policyname = 'Public can view project by share token'
  ) THEN
    CREATE POLICY "Public can view project by share token"
      ON sandbox_scale_projects FOR SELECT
      TO anon
      USING (shareable_link IS NOT NULL);
  END IF;
END $$;

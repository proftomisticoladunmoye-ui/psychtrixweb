/*
  # Add Cultural Adaptation Tables

  1. New Tables
    - `cultural_groups`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `dataset_id` (uuid, references datasets)
      - `name` (text) - Group name
      - `language` (text) - Language/locale
      - `sample_size` (integer)
      - `reliability` (numeric)
      - `mean_score` (numeric)
      - `sd_score` (numeric)
      - `status` (text) - active, pending, completed
      - `metadata` (jsonb) - Additional group info
      - `created_at` (timestamptz)

    - `dif_analyses`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `dataset_id` (uuid, references datasets)
      - `item_name` (text)
      - `group1_id` (uuid, references cultural_groups)
      - `group2_id` (uuid, references cultural_groups)
      - `dif_magnitude` (numeric)
      - `significance` (numeric)
      - `interpretation` (text) - negligible, moderate, large
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Users can access their own data

  3. Indexes
    - Index on user_id and dataset_id for fast queries
*/

-- Create cultural_groups table
CREATE TABLE IF NOT EXISTS cultural_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  dataset_id uuid REFERENCES datasets(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  language text NOT NULL,
  sample_size integer NOT NULL DEFAULT 0,
  reliability numeric,
  mean_score numeric,
  sd_score numeric,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('active', 'pending', 'completed')),
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create dif_analyses table
CREATE TABLE IF NOT EXISTS dif_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  dataset_id uuid REFERENCES datasets(id) ON DELETE CASCADE NOT NULL,
  item_name text NOT NULL,
  group1_id uuid REFERENCES cultural_groups(id) ON DELETE CASCADE NOT NULL,
  group2_id uuid REFERENCES cultural_groups(id) ON DELETE CASCADE NOT NULL,
  dif_magnitude numeric NOT NULL,
  significance numeric NOT NULL,
  interpretation text NOT NULL CHECK (interpretation IN ('negligible', 'moderate', 'large')),
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_cultural_groups_user_id ON cultural_groups(user_id);
CREATE INDEX IF NOT EXISTS idx_cultural_groups_dataset_id ON cultural_groups(dataset_id);
CREATE INDEX IF NOT EXISTS idx_dif_analyses_user_id ON dif_analyses(user_id);
CREATE INDEX IF NOT EXISTS idx_dif_analyses_dataset_id ON dif_analyses(dataset_id);
CREATE INDEX IF NOT EXISTS idx_dif_analyses_groups ON dif_analyses(group1_id, group2_id);

-- Enable Row Level Security
ALTER TABLE cultural_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE dif_analyses ENABLE ROW LEVEL SECURITY;

-- RLS Policies for cultural_groups
CREATE POLICY "Users can view own cultural groups"
  ON cultural_groups FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cultural groups"
  ON cultural_groups FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cultural groups"
  ON cultural_groups FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cultural groups"
  ON cultural_groups FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for dif_analyses
CREATE POLICY "Users can view own DIF analyses"
  ON dif_analyses FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own DIF analyses"
  ON dif_analyses FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own DIF analyses"
  ON dif_analyses FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
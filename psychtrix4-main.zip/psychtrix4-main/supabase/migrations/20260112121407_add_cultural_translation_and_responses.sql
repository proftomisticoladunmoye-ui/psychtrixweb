/*
  # Add Cultural Adaptation Translation and Response Tables

  1. New Tables
    - `translation_items`
      - Stores translation-back-translation workflow items
      - Links to user for ownership
      - Tracks translation status and progress

    - `cultural_responses`
      - Stores actual response data for cultural groups
      - Enables real DIF and invariance analysis
      - Automatically calculates total scores

  2. Security
    - Full RLS on both tables
    - Users can only access their own data
    - Performance indexes on key columns

  3. Automation
    - Auto-update timestamps
    - Auto-calculate total scores
*/

-- Create translation_items table
CREATE TABLE IF NOT EXISTS translation_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  original_text text NOT NULL,
  target_language text NOT NULL,
  forward_translation text DEFAULT '',
  back_translation text DEFAULT '',
  discrepancies text DEFAULT '',
  resolution text DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
  translator_name text,
  reviewer_name text,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create cultural_responses table
CREATE TABLE IF NOT EXISTS cultural_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES cultural_groups(id) ON DELETE CASCADE NOT NULL,
  participant_id text NOT NULL,
  item_responses jsonb NOT NULL,
  total_score numeric,
  response_time_seconds integer,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_translation_items_user_id ON translation_items(user_id);
CREATE INDEX IF NOT EXISTS idx_translation_items_status ON translation_items(status);
CREATE INDEX IF NOT EXISTS idx_cultural_responses_group_id ON cultural_responses(group_id);
CREATE INDEX IF NOT EXISTS idx_cultural_responses_participant_id ON cultural_responses(participant_id);

-- Enable Row Level Security
ALTER TABLE translation_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE cultural_responses ENABLE ROW LEVEL SECURITY;

-- RLS Policies for translation_items
CREATE POLICY "Users can view own translation items"
  ON translation_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own translation items"
  ON translation_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own translation items"
  ON translation_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own translation items"
  ON translation_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for cultural_responses
CREATE POLICY "Users can view responses from their groups"
  ON cultural_responses FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cultural_groups
      WHERE cultural_groups.id = cultural_responses.group_id
      AND cultural_groups.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert responses to their groups"
  ON cultural_responses FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM cultural_groups
      WHERE cultural_groups.id = cultural_responses.group_id
      AND cultural_groups.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete responses from their groups"
  ON cultural_responses FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cultural_groups
      WHERE cultural_groups.id = cultural_responses.group_id
      AND cultural_groups.user_id = auth.uid()
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_translation_items_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically update updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'set_translation_items_updated_at'
  ) THEN
    CREATE TRIGGER set_translation_items_updated_at
      BEFORE UPDATE ON translation_items
      FOR EACH ROW
      EXECUTE FUNCTION update_translation_items_updated_at();
  END IF;
END $$;

-- Function to automatically calculate total_score
CREATE OR REPLACE FUNCTION calculate_response_total_score()
RETURNS TRIGGER AS $$
DECLARE
  score numeric;
  response_array jsonb;
BEGIN
  response_array := NEW.item_responses;

  SELECT SUM((value::text)::numeric)
  INTO score
  FROM jsonb_array_elements(response_array) AS value
  WHERE jsonb_typeof(value) = 'number';

  NEW.total_score := score;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically calculate total_score
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'set_response_total_score'
  ) THEN
    CREATE TRIGGER set_response_total_score
      BEFORE INSERT OR UPDATE ON cultural_responses
      FOR EACH ROW
      EXECUTE FUNCTION calculate_response_total_score();
  END IF;
END $$;
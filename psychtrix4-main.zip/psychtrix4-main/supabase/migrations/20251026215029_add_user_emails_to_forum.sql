-- Add user_email to forum_posts
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'forum_posts' AND column_name = 'user_email'
  ) THEN
    ALTER TABLE forum_posts ADD COLUMN user_email text;
  END IF;
END $$;

-- Add user_email to forum_replies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'forum_replies' AND column_name = 'user_email'
  ) THEN
    ALTER TABLE forum_replies ADD COLUMN user_email text;
  END IF;
END $$;

-- Function to get user email from auth.users
CREATE OR REPLACE FUNCTION get_user_email(user_uuid uuid)
RETURNS text AS $$
DECLARE
  user_email text;
BEGIN
  SELECT email INTO user_email
  FROM auth.users
  WHERE id = user_uuid;
  RETURN COALESCE(user_email, 'Unknown User');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-populate user_email on forum_posts insert
CREATE OR REPLACE FUNCTION set_forum_post_user_email()
RETURNS trigger AS $$
BEGIN
  NEW.user_email := get_user_email(NEW.user_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS forum_posts_set_user_email ON forum_posts;
CREATE TRIGGER forum_posts_set_user_email
  BEFORE INSERT ON forum_posts
  FOR EACH ROW
  EXECUTE FUNCTION set_forum_post_user_email();

-- Trigger to auto-populate user_email on forum_replies insert
CREATE OR REPLACE FUNCTION set_forum_reply_user_email()
RETURNS trigger AS $$
BEGIN
  NEW.user_email := get_user_email(NEW.user_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS forum_replies_set_user_email ON forum_replies;
CREATE TRIGGER forum_replies_set_user_email
  BEFORE INSERT ON forum_replies
  FOR EACH ROW
  EXECUTE FUNCTION set_forum_reply_user_email();

-- Update existing posts with user emails
UPDATE forum_posts
SET user_email = get_user_email(user_id)
WHERE user_email IS NULL;

-- Update existing replies with user emails
UPDATE forum_replies
SET user_email = get_user_email(user_id)
WHERE user_email IS NULL;
/*
  # Fix Forum Views Function

  ## Changes
  - Remove the duplicate trigger-style `increment_forum_post_views` function
  - Restore the correct RPC-style function that accepts `post_uuid` parameter
  - This function is called from the frontend as an RPC function

  ## Function Details
  - Function: `increment_forum_post_views(post_uuid uuid)`
  - Purpose: Increment the view count for a forum post when users view it
  - Returns: void
  - Security: DEFINER with proper search_path
*/

-- Drop the trigger-style version and restore the RPC version
CREATE OR REPLACE FUNCTION increment_forum_post_views(post_uuid uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE forum_posts
  SET views_count = views_count + 1
  WHERE id = post_uuid;
END;
$$;

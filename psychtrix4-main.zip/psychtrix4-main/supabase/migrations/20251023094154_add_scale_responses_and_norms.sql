/*
  # Add Scale Responses and Normative Data Tables

  1. New Tables
    - `scale_responses`
      - `id` (uuid, primary key)
      - `project_id` (uuid, references sandbox_scale_projects)
      - `respondent_id` (text) - anonymous or identified respondent ID
      - `responses` (jsonb) - item responses {item_id: value}
      - `total_score` (numeric)
      - `demographic_data` (jsonb) - optional demographic info
      - `completed_at` (timestamptz)
      - `created_at` (timestamptz)

    - `expert_ratings`
      - `id` (uuid, primary key)
      - `project_id` (uuid, references sandbox_scale_projects)
      - `expert_id` (text) - expert identifier
      - `item_ratings` (jsonb) - relevance ratings per item {item_id: {relevance: 1-4, clarity: 1-4}}
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Users can access data for their own projects
    - Anonymous response submission allowed

  3. Indexes
    - Index on project_id for fast queries
    - Index on completed_at for temporal analysis
*/

-- Create scale_responses table
CREATE TABLE IF NOT EXISTS scale_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES sandbox_scale_projects(id) ON DELETE CASCADE NOT NULL,
  respondent_id text NOT NULL,
  responses jsonb NOT NULL DEFAULT '{}'::jsonb,
  total_score numeric,
  demographic_data jsonb DEFAULT '{}'::jsonb,
  completed_at timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create expert_ratings table
CREATE TABLE IF NOT EXISTS expert_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES sandbox_scale_projects(id) ON DELETE CASCADE NOT NULL,
  expert_id text NOT NULL,
  item_ratings jsonb NOT NULL DEFAULT '{}'::jsonb,
  comments text,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_scale_responses_project_id ON scale_responses(project_id);
CREATE INDEX IF NOT EXISTS idx_scale_responses_completed_at ON scale_responses(completed_at DESC);
CREATE INDEX IF NOT EXISTS idx_expert_ratings_project_id ON expert_ratings(project_id);

-- Enable Row Level Security
ALTER TABLE scale_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE expert_ratings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for scale_responses
CREATE POLICY "Project owners can view responses"
  ON scale_responses FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = scale_responses.project_id
      AND sandbox_scale_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can submit responses"
  ON scale_responses FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Project owners can delete responses"
  ON scale_responses FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = scale_responses.project_id
      AND sandbox_scale_projects.user_id = auth.uid()
    )
  );

-- RLS Policies for expert_ratings
CREATE POLICY "Project owners can view expert ratings"
  ON expert_ratings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = expert_ratings.project_id
      AND sandbox_scale_projects.user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can submit expert ratings"
  ON expert_ratings FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Project owners can delete expert ratings"
  ON expert_ratings FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sandbox_scale_projects
      WHERE sandbox_scale_projects.id = expert_ratings.project_id
      AND sandbox_scale_projects.user_id = auth.uid()
    )
  );
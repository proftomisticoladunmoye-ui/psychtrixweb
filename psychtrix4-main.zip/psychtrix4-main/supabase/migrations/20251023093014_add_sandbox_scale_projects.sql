/*
  # Add Sandbox Scale Projects Support

  1. New Tables
    - `sandbox_scale_projects`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text) - Project name
      - `description` (text) - Project description
      - `items` (jsonb) - Array of scale items with their properties
      - `reliability` (numeric) - Cronbach's alpha
      - `validity` (numeric) - Validity coefficient
      - `status` (text) - draft, testing, validated
      - `last_modified` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `sandbox_scale_projects` table
    - Add policies for authenticated users to manage their own projects

  3. Indexes
    - Index on user_id for fast queries
    - Index on status for filtering
    - Index on last_modified for sorting
*/

-- Create sandbox_scale_projects table
CREATE TABLE IF NOT EXISTS sandbox_scale_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text DEFAULT '' NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  reliability numeric,
  validity numeric,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'testing', 'validated')),
  last_modified timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_sandbox_projects_user_id ON sandbox_scale_projects(user_id);
CREATE INDEX IF NOT EXISTS idx_sandbox_projects_status ON sandbox_scale_projects(status);
CREATE INDEX IF NOT EXISTS idx_sandbox_projects_last_modified ON sandbox_scale_projects(last_modified DESC);

-- Enable Row Level Security
ALTER TABLE sandbox_scale_projects ENABLE ROW LEVEL SECURITY;

-- RLS Policies for sandbox_scale_projects
CREATE POLICY "Users can view own sandbox projects"
  ON sandbox_scale_projects FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own sandbox projects"
  ON sandbox_scale_projects FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sandbox projects"
  ON sandbox_scale_projects FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own sandbox projects"
  ON sandbox_scale_projects FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create trigger for last_modified
CREATE TRIGGER update_sandbox_projects_last_modified
  BEFORE UPDATE ON sandbox_scale_projects
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Modify the trigger function call to update last_modified instead
DROP TRIGGER IF EXISTS update_sandbox_projects_last_modified ON sandbox_scale_projects;

CREATE OR REPLACE FUNCTION update_last_modified_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_modified = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_sandbox_projects_last_modified
  BEFORE UPDATE ON sandbox_scale_projects
  FOR EACH ROW
  EXECUTE FUNCTION update_last_modified_column();
-- Add forum admin table and enhance existing forum
CREATE TABLE IF NOT EXISTS forum_admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  email text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE forum_admins ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view forum admins"
  ON forum_admins FOR SELECT
  TO public
  USING (true);

-- Add pinned field to forum_posts if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'forum_posts' AND column_name = 'is_pinned'
  ) THEN
    ALTER TABLE forum_posts ADD COLUMN is_pinned boolean DEFAULT false;
  END IF;
END $$;

-- Add views_count to forum_posts if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'forum_posts' AND column_name = 'views_count'
  ) THEN
    ALTER TABLE forum_posts ADD COLUMN views_count integer DEFAULT 0;
  END IF;
END $$;

-- Add is_solution to forum_replies if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'forum_replies' AND column_name = 'is_solution'
  ) THEN
    ALTER TABLE forum_replies ADD COLUMN is_solution boolean DEFAULT false;
  END IF;
END $$;

-- Add policies for admin actions on forum_posts
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'forum_posts' AND policyname = 'Admins can pin posts'
  ) THEN
    EXECUTE 'CREATE POLICY "Admins can pin posts"
      ON forum_posts FOR UPDATE
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM forum_admins
          WHERE forum_admins.user_id = auth.uid()
        )
      )';
  END IF;
END $$;

-- Add policy for marking solutions
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'forum_replies' AND policyname = 'Post authors can mark solution'
  ) THEN
    EXECUTE 'CREATE POLICY "Post authors can mark solution"
      ON forum_replies FOR UPDATE
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM forum_posts
          WHERE forum_posts.id = forum_replies.post_id
          AND forum_posts.user_id = auth.uid()
        )
      )';
  END IF;
END $$;

-- Function to increment views
CREATE OR REPLACE FUNCTION increment_forum_post_views(post_uuid uuid)
RETURNS void AS $$
BEGIN
  UPDATE forum_posts
  SET views_count = views_count + 1
  WHERE id = post_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
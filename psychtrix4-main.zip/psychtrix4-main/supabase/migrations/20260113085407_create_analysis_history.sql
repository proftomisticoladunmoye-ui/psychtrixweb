/*
  # Create Analysis History System

  1. New Tables
    - `analysis_history`
      - `id` (uuid, primary key) - Unique identifier
      - `user_id` (uuid, foreign key) - Links to auth.users
      - `analysis_type` (text) - Type of analysis (ctt, irt, efa, cfa, sem, etc.)
      - `analysis_name` (text) - User-friendly name
      - `dataset_id` (uuid, foreign key, nullable) - Links to datasets table
      - `dataset_name` (text, nullable) - Snapshot of dataset name
      - `configuration` (jsonb) - Analysis configuration/parameters
      - `results` (jsonb) - Complete analysis results
      - `status` (text) - Status (completed, failed, etc.)
      - `error_message` (text, nullable) - Error details if failed
      - `created_at` (timestamptz) - When analysis was run
      - `updated_at` (timestamptz) - Last update time

  2. Security
    - Enable RLS on `analysis_history` table
    - Add policies for users to manage their own analyses

  3. Indexes
    - Index on user_id for fast lookups
    - Index on analysis_type for filtering
    - Index on created_at for sorting
*/

-- Create analysis_history table
CREATE TABLE IF NOT EXISTS analysis_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  analysis_type text NOT NULL CHECK (analysis_type IN (
    'ctt', 'irt', 'efa', 'cfa', 'sem', 'path', 'mediation',
    'invariance', 'multigroup', 'content_validity', 'cvr', 'cvi',
    'cat', 'plssem', 'cultural_adaptation'
  )),
  analysis_name text NOT NULL,
  dataset_id uuid REFERENCES datasets(id) ON DELETE SET NULL,
  dataset_name text,
  configuration jsonb NOT NULL DEFAULT '{}'::jsonb,
  results jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed', 'failed', 'partial')),
  error_message text,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_analysis_history_user_id ON analysis_history(user_id);
CREATE INDEX IF NOT EXISTS idx_analysis_history_type ON analysis_history(analysis_type);
CREATE INDEX IF NOT EXISTS idx_analysis_history_created_at ON analysis_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_analysis_history_dataset_id ON analysis_history(dataset_id) WHERE dataset_id IS NOT NULL;

-- Enable RLS
ALTER TABLE analysis_history ENABLE ROW LEVEL SECURITY;

-- Policies for analysis_history
CREATE POLICY "Users can view own analysis history"
  ON analysis_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own analysis history"
  ON analysis_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own analysis history"
  ON analysis_history FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own analysis history"
  ON analysis_history FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_analysis_history_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-update updated_at
DROP TRIGGER IF EXISTS trigger_update_analysis_history_updated_at ON analysis_history;
CREATE TRIGGER trigger_update_analysis_history_updated_at
  BEFORE UPDATE ON analysis_history
  FOR EACH ROW
  EXECUTE FUNCTION update_analysis_history_updated_at();